import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  json,
  decimal,
  longtext,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Conversations table: stores chat sessions per user
 */
export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  model: varchar("model", { length: 64 }).default("nemotron").notNull(), // "nemotron" (fast), "granite-4" (powerful)
  status: mysqlEnum("status", ["active", "archived", "deleted"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;

/**
 * Messages table: stores individual messages in conversations
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  content: longtext("content").notNull(),
  markdown: boolean("markdown").default(true),
  toolCalls: json("toolCalls"), // Array of tool invocations
  toolResults: json("toolResults"), // Array of tool results
  reasoning: longtext("reasoning"), // Agent's reasoning/thought process
  streamingId: varchar("streamingId", { length: 64 }), // For real-time streaming
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

/**
 * Tasks table: stores autonomous agent tasks
 */
export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId"),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: longtext("description"),
  status: mysqlEnum("status", ["pending", "running", "completed", "failed", "cancelled"]).default("pending").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium").notNull(),
  executionSteps: json("executionSteps"), // Array of execution steps with status
  result: longtext("result"),
  error: text("error"),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

/**
 * Files table: stores uploaded files for processing
 */
export const files = mysqlTable("files", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  conversationId: int("conversationId"),
  taskId: int("taskId"),
  filename: varchar("filename", { length: 255 }).notNull(),
  mimeType: varchar("mimeType", { length: 64 }).notNull(),
  fileKey: varchar("fileKey", { length: 255 }).notNull(), // S3 storage key
  fileUrl: varchar("fileUrl", { length: 512 }), // S3 presigned URL
  fileSize: int("fileSize"),
  metadata: json("metadata"), // Additional file metadata
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type File = typeof files.$inferSelect;
export type InsertFile = typeof files.$inferInsert;

/**
 * Scheduled tasks table: for recurring/future-dated autonomous operations
 */
export const scheduledTasks = mysqlTable("scheduledTasks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: longtext("description"),
  cronExpression: varchar("cronExpression", { length: 64 }),
  intervalSeconds: int("intervalSeconds"),
  isRecurring: boolean("isRecurring").default(false),
  isEnabled: boolean("isEnabled").default(true),
  nextRunAt: timestamp("nextRunAt"),
  lastRunAt: timestamp("lastRunAt"),
  expiresAt: timestamp("expiresAt"),
  taskTemplate: json("taskTemplate"), // Template for task creation
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ScheduledTask = typeof scheduledTasks.$inferSelect;
export type InsertScheduledTask = typeof scheduledTasks.$inferInsert;

/**
 * Skills table: stores available skills and their metadata
 */
export const skills = mysqlTable("skills", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"), // NULL = global skill
  skillName: varchar("skillName", { length: 255 }).notNull(),
  description: longtext("description"),
  skillId: varchar("skillId", { length: 128 }).notNull().unique(),
  enabled: boolean("enabled").default(true),
  metadata: json("metadata"), // Skill-specific configuration
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Skill = typeof skills.$inferSelect;
export type InsertSkill = typeof skills.$inferInsert;

/**
 * Connectors table: stores external service integrations
 */
export const connectors = mysqlTable("connectors", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"), // NULL = global connector
  connectorName: varchar("connectorName", { length: 255 }).notNull(),
  connectorType: varchar("connectorType", { length: 64 }).notNull(), // "github", "huggingface", "custom_api", etc.
  connectorUid: varchar("connectorUid", { length: 128 }).notNull().unique(),
  enabled: boolean("enabled").default(true),
  config: json("config"), // Encrypted connector configuration
  credentials: json("credentials"), // Encrypted credentials (API keys, tokens)
  metadata: json("metadata"), // Additional metadata
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Connector = typeof connectors.$inferSelect;
export type InsertConnector = typeof connectors.$inferInsert;

/**
 * Tool executions table: tracks tool invocations and results
 */
export const toolExecutions = mysqlTable("toolExecutions", {
  id: int("id").autoincrement().primaryKey(),
  taskId: int("taskId").notNull(),
  messageId: int("messageId"),
  toolName: varchar("toolName", { length: 255 }).notNull(),
  toolType: varchar("toolType", { length: 64 }).notNull(), // "web_search", "code_execution", "file_io", "data_analysis", "image_generation"
  input: json("input").notNull(),
  output: longtext("output"),
  status: mysqlEnum("status", ["pending", "running", "completed", "failed"]).default("pending").notNull(),
  error: text("error"),
  executionTime: int("executionTime"), // milliseconds
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
});

export type ToolExecution = typeof toolExecutions.$inferSelect;
export type InsertToolExecution = typeof toolExecutions.$inferInsert;

/**
 * Agent reasoning steps table: tracks the agent's reasoning process
 */
export const reasoningSteps = mysqlTable("reasoningSteps", {
  id: int("id").autoincrement().primaryKey(),
  taskId: int("taskId").notNull(),
  messageId: int("messageId"),
  stepNumber: int("stepNumber").notNull(),
  stepType: varchar("stepType", { length: 64 }).notNull(), // "planning", "reasoning", "tool_call", "decision", "reflection"
  content: longtext("content").notNull(),
  status: mysqlEnum("status", ["pending", "active", "completed"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ReasoningStep = typeof reasoningSteps.$inferSelect;
export type InsertReasoningStep = typeof reasoningSteps.$inferInsert;

/**
 * Notifications table: for owner notifications and system alerts
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: varchar("type", { length: 64 }).notNull(), // "user_signup", "task_completed", "task_failed", "system_alert"
  title: varchar("title", { length: 255 }).notNull(),
  content: longtext("content"),
  read: boolean("read").default(false),
  actionUrl: varchar("actionUrl", { length: 512 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Webhooks table: for external integrations and callbacks
 */
export const webhooks = mysqlTable("webhooks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  url: varchar("url", { length: 512 }).notNull(),
  events: json("events"), // Array of events to subscribe to
  secret: varchar("secret", { length: 255 }), // For HMAC signature verification
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Webhook = typeof webhooks.$inferSelect;
export type InsertWebhook = typeof webhooks.$inferInsert;

/**
 * Image generations table: tracks generated images
 */
export const imageGenerations = mysqlTable("imageGenerations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  conversationId: int("conversationId"),
  taskId: int("taskId"),
  prompt: longtext("prompt").notNull(),
  imageUrl: varchar("imageUrl", { length: 512 }),
  fileKey: varchar("fileKey", { length: 255 }), // S3 storage key
  model: varchar("model", { length: 64 }).default("dall-e-3"),
  status: mysqlEnum("status", ["pending", "completed", "failed"]).default("pending").notNull(),
  error: text("error"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
});

export type ImageGeneration = typeof imageGenerations.$inferSelect;
export type InsertImageGeneration = typeof imageGenerations.$inferInsert;

/**
 * Voice transcriptions table: tracks voice-to-text conversions
 */
export const voiceTranscriptions = mysqlTable("voiceTranscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  conversationId: int("conversationId"),
  audioUrl: varchar("audioUrl", { length: 512 }).notNull(),
  fileKey: varchar("fileKey", { length: 255 }), // S3 storage key
  transcription: longtext("transcription"),
  language: varchar("language", { length: 16 }).default("en"),
  status: mysqlEnum("status", ["pending", "completed", "failed"]).default("pending").notNull(),
  error: text("error"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
});

export type VoiceTranscription = typeof voiceTranscriptions.$inferSelect;
export type InsertVoiceTranscription = typeof voiceTranscriptions.$inferInsert;
