import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { invokeAgent, executeTool } from "./agent";
import { wideResearch, selectModel, analyzeComplexity } from "./parallelProcessing";
import { ultraPowerfulReasoning } from "./reasoning";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Conversation management
  conversations: router({
    create: protectedProcedure
      .input(
        z.object({
          title: z.string().min(1),
          model: z.enum(["nemotron-4b", "granite-4"]).default("nemotron-4b"),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return db.createConversation(ctx.user.id, input.title, input.model);
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getConversations(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ input, ctx }) => {
        return db.getConversationById(input.conversationId, ctx.user.id);
      }),
  }),

  // Message and chat operations
  messages: router({
    list: protectedProcedure
      .input(
        z.object({
          conversationId: z.number(),
          limit: z.number().default(50),
        })
      )
      .query(async ({ input, ctx }) => {
        // Verify user owns this conversation
        const conversation = await db.getConversationById(
          input.conversationId,
          ctx.user.id
        );
        if (!conversation) throw new Error("Conversation not found");

        return db.getMessages(input.conversationId, input.limit);
      }),

    send: protectedProcedure
      .input(
        z.object({
          conversationId: z.number(),
          content: z.string().min(1),
          model: z.enum(["nemotron-4b", "granite-4"]).optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Verify user owns this conversation
        const conversation = await db.getConversationById(
          input.conversationId,
          ctx.user.id
        );
        if (!conversation) throw new Error("Conversation not found");

        // Create user message
        const userMessage = await db.createMessage(
          input.conversationId,
          ctx.user.id,
          "user",
          input.content
        );

        // Get conversation history
        const messages = await db.getMessages(input.conversationId, 10);

        // Select model
        const model = input.model || (conversation.model as any);
        const complexity = analyzeComplexity(input.content);

        // Invoke agent
        const agentResponse = await invokeAgent(
          input.content,
          messages.map((m) => ({
            role: m.role as "user" | "assistant" | "system",
            content: m.content,
          })),
          model,
          []
        );

        // Create assistant message
        const assistantMessage = await db.createMessage(
          input.conversationId,
          ctx.user.id,
          "assistant",
          agentResponse.content,
          agentResponse.reasoning,
          agentResponse.toolCalls,
          []
        );

        return {
          userMessage,
          assistantMessage,
          reasoning: agentResponse.reasoning,
          toolCalls: agentResponse.toolCalls,
          reasoningSteps: agentResponse.reasoningSteps,
        };
      }),
  }),

  // Task management
  tasks: router({
    create: protectedProcedure
      .input(
        z.object({
          title: z.string().min(1),
          description: z.string().optional(),
          conversationId: z.number().optional(),
          priority: z.enum(["low", "medium", "high", "critical"]).default("medium"),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return db.createTask(
          ctx.user.id,
          input.title,
          input.description,
          input.conversationId,
          input.priority
        );
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getTasks(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ taskId: z.number() }))
      .query(async ({ input, ctx }) => {
        return db.getTaskById(input.taskId, ctx.user.id);
      }),

    updateStatus: protectedProcedure
      .input(
        z.object({
          taskId: z.number(),
          status: z.enum(["pending", "running", "completed", "failed", "cancelled"]),
          result: z.string().optional(),
          error: z.string().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Verify user owns this task
        const task = await db.getTaskById(input.taskId, ctx.user.id);
        if (!task) throw new Error("Task not found");

        return db.updateTaskStatus(
          input.taskId,
          input.status,
          input.result,
          input.error
        );
      }),
  }),

  // File management
  files: router({
    list: protectedProcedure
      .input(
        z.object({
          conversationId: z.number().optional(),
        })
      )
      .query(async ({ input, ctx }) => {
        return db.getFiles(ctx.user.id, input.conversationId);
      }),

    upload: protectedProcedure
      .input(
        z.object({
          filename: z.string(),
          mimeType: z.string(),
          fileKey: z.string(),
          fileUrl: z.string().optional(),
          fileSize: z.number().optional(),
          conversationId: z.number().optional(),
          taskId: z.number().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return db.createFile(
          ctx.user.id,
          input.filename,
          input.mimeType,
          input.fileKey,
          input.fileUrl,
          input.fileSize,
          input.conversationId,
          input.taskId
        );
      }),
  }),

  // Advanced reasoning
  reasoning: router({
    ultraPowerful: protectedProcedure
      .input(
        z.object({
          problem: z.string().min(1),
          context: z.string().optional(),
          maxPaths: z.number().default(3),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return ultraPowerfulReasoning(input.problem, input.context || "", input.maxPaths);
      }),
  }),

  // Parallel processing and model selection
  models: router({
    selectBest: protectedProcedure
      .input(
        z.object({
          query: z.string().min(1),
        })
      )
      .query(async ({ input, ctx }) => {
        const complexity = analyzeComplexity(input.query);
        const model = selectModel(input.query, complexity, {
          defaultModel: "nemotron-4b",
          autoToggle: true,
          complexityThreshold: 0.6,
          performanceMetrics: {
            nemotron: { avgLatency: 500, avgQuality: 0.8 },
            granite: { avgLatency: 2000, avgQuality: 0.95 },
          },
        });

        return {
          model,
          complexity,
          recommendation: model === "granite-4" ? "powerful" : "fast",
        };
      }),

    wideResearch: protectedProcedure
      .input(
        z.object({
          query: z.string().min(1),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return wideResearch(input.query, {
          defaultModel: "nemotron-4b",
          autoToggle: true,
          complexityThreshold: 0.6,
          performanceMetrics: {
            nemotron: { avgLatency: 500, avgQuality: 0.8 },
            granite: { avgLatency: 2000, avgQuality: 0.95 },
          },
        });
      }),
  }),

  // Notifications
  notifications: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getNotifications(ctx.user.id);
    }),
  }),

  // Skills management
  skills: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getSkills(ctx.user.id);
    }),
  }),

  // Connectors management
  connectors: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getConnectors(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          connectorName: z.string(),
          connectorType: z.string(),
          connectorUid: z.string(),
          config: z.record(z.string(), z.any()).optional(),
          credentials: z.record(z.string(), z.any()).optional(),
          metadata: z.record(z.string(), z.any()).optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return db.createConnector(
          input.connectorName,
          input.connectorType,
          input.connectorUid,
          input.config,
          input.credentials,
          ctx.user.id,
          input.metadata
        );
      }),
  }),

  // Scheduled tasks
  scheduledTasks: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getScheduledTasks(ctx.user.id);
    }),

    create: protectedProcedure
      .input(
        z.object({
          title: z.string().min(1),
          description: z.string().optional(),
          cronExpression: z.string().optional(),
          intervalSeconds: z.number().optional(),
          taskTemplate: z.record(z.string(), z.any()).optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return db.createScheduledTask(
          ctx.user.id,
          input.title,
          input.description,
          input.cronExpression,
          input.intervalSeconds,
          input.taskTemplate
        );
      }),
  }),

  // Image generation
  imageGeneration: router({
    generate: protectedProcedure
      .input(
        z.object({
          prompt: z.string().min(1),
          conversationId: z.number().optional(),
          taskId: z.number().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return db.createImageGeneration(
          ctx.user.id,
          input.prompt,
          input.conversationId,
          input.taskId
        );
      }),
  }),

  // Voice transcription
  voiceTranscription: router({
    transcribe: protectedProcedure
      .input(
        z.object({
          audioUrl: z.string(),
          conversationId: z.number().optional(),
          language: z.string().default("en"),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return db.createVoiceTranscription(
          ctx.user.id,
          input.audioUrl,
          undefined,
          input.conversationId,
          input.language
        );
      }),
  }),
});

export type AppRouter = typeof appRouter;
