import { invokeLLM } from "./_core/llm";

/**
 * Parallel Processing Engine (Wide Research)
 * Enables concurrent multi-model inference with intelligent routing
 * Supports Nemotron 4B (fast) and Granite 4 (powerful reasoning)
 */

export type ModelType = "nemotron-4b" | "granite-4";
export type TaskComplexity = "simple" | "moderate" | "complex" | "ultra-complex";

export interface ParallelTask {
  taskId: string;
  query: string;
  model: ModelType;
  priority: number;
  timeout: number;
  status: "pending" | "running" | "completed" | "failed";
  result?: string;
  error?: string;
  executionTime?: number;
}

export interface WideResearchResult {
  query: string;
  nemotronResult: {
    content: string;
    executionTime: number;
    confidence: number;
  };
  graniteResult: {
    content: string;
    executionTime: number;
    confidence: number;
  };
  synthesis: string;
  recommendation: "use-nemotron" | "use-granite" | "use-both";
  complexity: TaskComplexity;
}

export interface ModelToggleConfig {
  defaultModel: ModelType;
  autoToggle: boolean;
  complexityThreshold: number;
  performanceMetrics: {
    nemotron: { avgLatency: number; avgQuality: number };
    granite: { avgLatency: number; avgQuality: number };
  };
}

/**
 * Intelligent model selector based on task complexity
 */
export function selectModel(
  query: string,
  complexity: TaskComplexity,
  config: ModelToggleConfig
): ModelType {
  if (!config.autoToggle) {
    return config.defaultModel;
  }

  // Complexity-based routing
  switch (complexity) {
    case "simple":
      return "nemotron-4b"; // Fast for simple queries
    case "moderate":
      return "nemotron-4b"; // Still fast enough
    case "complex":
      return "granite-4"; // Need reasoning
    case "ultra-complex":
      return "granite-4"; // Full reasoning power
    default:
      return config.defaultModel;
  }
}

/**
 * Analyze query complexity using heuristics
 */
export function analyzeComplexity(query: string): TaskComplexity {
  const wordCount = query.split(/\s+/).length;
  const hasMultipleQuestions = (query.match(/\?/g) || []).length > 1;
  const hasConditionals = /if|when|unless|given|assuming/i.test(query);
  const hasComparisons = /compare|versus|vs|difference|similar/i.test(query);
  const hasAbstractions = /concept|theory|philosophy|abstract|principle/i.test(query);

  let complexityScore = 0;

  if (wordCount > 50) complexityScore += 2;
  if (wordCount > 100) complexityScore += 2;
  if (hasMultipleQuestions) complexityScore += 2;
  if (hasConditionals) complexityScore += 2;
  if (hasComparisons) complexityScore += 1;
  if (hasAbstractions) complexityScore += 2;

  if (complexityScore >= 7) return "ultra-complex";
  if (complexityScore >= 5) return "complex";
  if (complexityScore >= 2) return "moderate";
  return "simple";
}

/**
 * Wide Research: Parallel processing with both models
 */
export async function wideResearch(
  query: string,
  config: ModelToggleConfig
): Promise<WideResearchResult> {
  const complexity = analyzeComplexity(query);
  const startTime = Date.now();

  // Run both models in parallel
  const [nemotronResult, graniteResult] = await Promise.all([
    invokeModel(query, "nemotron-4b"),
    invokeModel(query, "granite-4"),
  ]);

  const totalTime = Date.now() - startTime;

  // Synthesize results
  const synthesis = await synthesizeResults(query, nemotronResult, graniteResult);

  // Determine recommendation
  const recommendation = determineRecommendation(
    nemotronResult,
    graniteResult,
    complexity
  );

  return {
    query,
    nemotronResult: {
      content: nemotronResult.content,
      executionTime: nemotronResult.executionTime,
      confidence: nemotronResult.confidence,
    },
    graniteResult: {
      content: graniteResult.content,
      executionTime: graniteResult.executionTime,
      confidence: graniteResult.confidence,
    },
    synthesis,
    recommendation,
    complexity,
  };
}

/**
 * Invoke a specific model
 */
async function invokeModel(
  query: string,
  model: ModelType
): Promise<{
  content: string;
  executionTime: number;
  confidence: number;
}> {
  const startTime = Date.now();

  const systemPrompt = getSystemPromptForModel(model);

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: systemPrompt,
        },
        {
          role: "user",
          content: query,
        },
      ],
    });

    const content = extractContent(response);
    const executionTime = Date.now() - startTime;
    const confidence = calculateConfidence(content, model);

    return {
      content,
      executionTime,
      confidence,
    };
  } catch (error) {
    return {
      content: `Error invoking ${model}: ${error}`,
      executionTime: Date.now() - startTime,
      confidence: 0,
    };
  }
}

/**
 * Get system prompt tailored to model
 */
function getSystemPromptForModel(model: ModelType): string {
  if (model === "nemotron-4b") {
    return `You are Nemotron 4B, an efficient and fast instruction-tuned model.
Provide concise, direct answers with practical insights.
Focus on clarity and speed.
Avoid unnecessary elaboration.
Format responses for quick comprehension.`;
  }

  return `You are Granite 4, an advanced reasoning model with superior analytical capabilities.
Provide comprehensive, deeply reasoned responses.
Include multiple perspectives and thorough analysis.
Explain your reasoning process.
Consider edge cases and implications.`;
}

/**
 * Extract content from LLM response
 */
function extractContent(response: any): string {
  if (typeof response === "string") return response;
  if (response?.choices?.[0]?.message?.content) {
    const content = response.choices[0].message.content;
    return typeof content === "string" ? content : String(content);
  }
  return String(response);
}

/**
 * Calculate confidence score for response
 */
function calculateConfidence(content: string, model: ModelType): number {
  let confidence = 0.5;

  // Length heuristic
  if (content.length > 500) confidence += 0.15;
  if (content.length > 1000) confidence += 0.1;

  // Reasoning indicators
  if (content.toLowerCase().includes("reason") || content.toLowerCase().includes("because")) {
    confidence += 0.1;
  }

  // Structure indicators
  if (content.includes("\n") && (content.match(/\n/g) || []).length > 3) {
    confidence += 0.1;
  }

  // Model-specific adjustments
  if (model === "granite-4") {
    confidence += 0.1; // Granite typically more confident
  }

  return Math.min(confidence, 1);
}

/**
 * Synthesize results from both models
 */
async function synthesizeResults(
  query: string,
  nemotronResult: any,
  graniteResult: any
): Promise<string> {
  const systemPrompt = `You are a synthesis expert combining insights from two AI models.
Create a unified, comprehensive response that:
1. Identifies common ground between the models
2. Highlights unique insights from each
3. Resolves any contradictions
4. Provides the most valuable synthesis

Be concise but thorough.`;

  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: systemPrompt,
        },
        {
          role: "user",
          content: `Query: ${query}

Nemotron 4B Response:
${nemotronResult.content}

Granite 4 Response:
${graniteResult.content}

Synthesize these into a unified response.`,
        },
      ],
    });

    return extractContent(response);
  } catch (error) {
    return `Synthesis failed: ${error}`;
  }
}

/**
 * Determine which model to recommend
 */
function determineRecommendation(
  nemotronResult: any,
  graniteResult: any,
  complexity: TaskComplexity
): "use-nemotron" | "use-granite" | "use-both" {
  // For complex tasks, prefer Granite
  if (complexity === "complex" || complexity === "ultra-complex") {
    if (graniteResult.confidence > nemotronResult.confidence) {
      return "use-granite";
    }
  }

  // For simple tasks, prefer Nemotron (faster)
  if (complexity === "simple" || complexity === "moderate") {
    if (nemotronResult.executionTime < graniteResult.executionTime * 0.7) {
      return "use-nemotron";
    }
  }

  // If both are good, use both for comprehensive coverage
  if (nemotronResult.confidence > 0.7 && graniteResult.confidence > 0.7) {
    return "use-both";
  }

  // Default to Granite for reliability
  return "use-granite";
}

/**
 * Parallel task queue manager
 */
export class ParallelTaskQueue {
  private tasks: Map<string, ParallelTask> = new Map();
  private maxConcurrent: number;
  private running: number = 0;

  constructor(maxConcurrent: number = 5) {
    this.maxConcurrent = maxConcurrent;
  }

  /**
   * Add task to queue
   */
  addTask(
    query: string,
    model: ModelType,
    priority: number = 0,
    timeout: number = 30000
  ): string {
    const taskId = `task-${Date.now()}-${Math.random()}`;
    const task: ParallelTask = {
      taskId,
      query,
      model,
      priority,
      timeout,
      status: "pending",
    };

    this.tasks.set(taskId, task);
    this.processQueue();

    return taskId;
  }

  /**
   * Get task result
   */
  getTask(taskId: string): ParallelTask | undefined {
    return this.tasks.get(taskId);
  }

  /**
   * Process queue
   */
  private async processQueue(): Promise<void> {
    while (this.running < this.maxConcurrent) {
      const task = this.getNextTask();
      if (!task) break;

      this.running++;
      this.executeTask(task).finally(() => {
        this.running--;
        this.processQueue();
      });
    }
  }

  /**
   * Get next task to execute
   */
  private getNextTask(): ParallelTask | undefined {
    let nextTask: ParallelTask | undefined;
    let highestPriority = -Infinity;

    this.tasks.forEach((task) => {
      if (task.status === "pending" && task.priority > highestPriority) {
        nextTask = task;
        highestPriority = task.priority;
      }
    });

    return nextTask;
  }

  /**
   * Execute a single task
   */
  private async executeTask(task: ParallelTask): Promise<void> {
    task.status = "running";
    const startTime = Date.now();

    try {
      const result = await Promise.race([
        invokeModel(task.query, task.model),
        new Promise((_, reject) =>
          setTimeout(
            () => reject(new Error("Task timeout")),
            task.timeout
          )
        ),
      ]);

      task.result = (result as any).content;
      task.executionTime = Date.now() - startTime;
      task.status = "completed";
    } catch (error) {
      task.error = String(error);
      task.executionTime = Date.now() - startTime;
      task.status = "failed";
    }
  }

  /**
   * Get all completed tasks
   */
  getCompletedTasks(): ParallelTask[] {
    const tasks: ParallelTask[] = [];
    this.tasks.forEach((task) => {
      if (task.status === "completed") {
        tasks.push(task);
      }
    });
    return tasks;
  }

  /**
   * Clear completed tasks
   */
  clearCompleted(): void {
    const toDelete: string[] = [];
    this.tasks.forEach((task, taskId) => {
      if (task.status === "completed" || task.status === "failed") {
        toDelete.push(taskId);
      }
    });
    toDelete.forEach((taskId) => this.tasks.delete(taskId));
  }
}

/**
 * Model performance tracker
 */
export class ModelPerformanceTracker {
  private nemotronMetrics = { latencies: [] as number[], qualities: [] as number[] };
  private graniteMetrics = { latencies: [] as number[], qualities: [] as number[] };

  /**
   * Record execution
   */
  recordExecution(
    model: ModelType,
    latency: number,
    quality: number
  ): void {
    if (model === "nemotron-4b") {
      this.nemotronMetrics.latencies.push(latency);
      this.nemotronMetrics.qualities.push(quality);
    } else {
      this.graniteMetrics.latencies.push(latency);
      this.graniteMetrics.qualities.push(quality);
    }
  }

  /**
   * Get average metrics
   */
  getMetrics(): ModelToggleConfig["performanceMetrics"] {
    return {
      nemotron: {
        avgLatency: this.average(this.nemotronMetrics.latencies),
        avgQuality: this.average(this.nemotronMetrics.qualities),
      },
      granite: {
        avgLatency: this.average(this.graniteMetrics.latencies),
        avgQuality: this.average(this.graniteMetrics.qualities),
      },
    };
  }

  /**
   * Calculate average
   */
  private average(values: number[]): number {
    if (values.length === 0) return 0;
    return values.reduce((a, b) => a + b, 0) / values.length;
  }
}
