import { eq, desc, and, isNull, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  conversations,
  messages,
  tasks,
  files,
  scheduledTasks,
  skills,
  connectors,
  toolExecutions,
  reasoningSteps,
  notifications,
  webhooks,
  imageGenerations,
  voiceTranscriptions,
  Conversation,
  Message,
  Task,
  File,
  ScheduledTask,
  Skill,
  Connector,
  ToolExecution,
  ReasoningStep,
  Notification,
  Webhook,
  ImageGeneration,
  VoiceTranscription,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Conversation queries
export async function createConversation(
  userId: number,
  title: string,
  model: string = "standard"
): Promise<Conversation> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(conversations).values({
    userId,
    title,
    model,
  });

  const id = (result as any).insertId;
  const created = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, id))
    .limit(1);

  return created[0];
}

export async function getConversations(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(conversations)
    .where(
      and(eq(conversations.userId, userId), eq(conversations.status, "active"))
    )
    .orderBy(desc(conversations.updatedAt));
}

export async function getConversationById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, userId)))
    .limit(1);

  return result[0] || null;
}

// Message queries
export async function createMessage(
  conversationId: number,
  userId: number,
  role: "user" | "assistant" | "system",
  content: string,
  reasoning?: string,
  toolCalls?: any,
  toolResults?: any
): Promise<Message> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(messages).values({
    conversationId,
    userId,
    role,
    content,
    reasoning,
    toolCalls,
    toolResults,
  });

  const id = (result as any).insertId;
  const created = await db
    .select()
    .from(messages)
    .where(eq(messages.id, id))
    .limit(1);

  return created[0];
}

export async function getMessages(conversationId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(desc(messages.createdAt))
    .limit(limit);
}

// Task queries
export async function createTask(
  userId: number,
  title: string,
  description?: string,
  conversationId?: number,
  priority: "low" | "medium" | "high" | "critical" = "medium"
): Promise<Task> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(tasks).values({
    userId,
    title,
    description,
    conversationId,
    priority,
  });

  const id = (result as any).insertId;
  const created = await db
    .select()
    .from(tasks)
    .where(eq(tasks.id, id))
    .limit(1);

  return created[0];
}

export async function updateTaskStatus(
  taskId: number,
  status: "pending" | "running" | "completed" | "failed" | "cancelled",
  result?: string,
  error?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updates: any = { status };
  if (result) updates.result = result;
  if (error) updates.error = error;
  if (status === "running" && !updates.startedAt) updates.startedAt = new Date();
  if (
    (status === "completed" || status === "failed" || status === "cancelled") &&
    !updates.completedAt
  )
    updates.completedAt = new Date();

  return db.update(tasks).set(updates).where(eq(tasks.id, taskId));
}

export async function getTasks(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(tasks)
    .where(eq(tasks.userId, userId))
    .orderBy(desc(tasks.createdAt))
    .limit(limit);
}

export async function getTaskById(taskId: number, userId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(tasks)
    .where(and(eq(tasks.id, taskId), eq(tasks.userId, userId)))
    .limit(1);

  return result[0] || null;
}

// File queries
export async function createFile(
  userId: number,
  filename: string,
  mimeType: string,
  fileKey: string,
  fileUrl?: string,
  fileSize?: number,
  conversationId?: number,
  taskId?: number
): Promise<File> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(files).values({
    userId,
    filename,
    mimeType,
    fileKey,
    fileUrl,
    fileSize,
    conversationId,
    taskId,
  });

  const id = (result as any).insertId;
  const created = await db
    .select()
    .from(files)
    .where(eq(files.id, id))
    .limit(1);

  return created[0];
}

export async function getFiles(userId: number, conversationId?: number) {
  const db = await getDb();
  if (!db) return [];

  if (conversationId) {
    return db
      .select()
      .from(files)
      .where(
        and(eq(files.userId, userId), eq(files.conversationId, conversationId))
      )
      .orderBy(desc(files.createdAt));
  }

  return db
    .select()
    .from(files)
    .where(eq(files.userId, userId))
    .orderBy(desc(files.createdAt));
}

// Scheduled task queries
export async function createScheduledTask(
  userId: number,
  title: string,
  description?: string,
  cronExpression?: string,
  intervalSeconds?: number,
  taskTemplate?: any
): Promise<ScheduledTask> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(scheduledTasks).values({
    userId,
    title,
    description,
    cronExpression,
    intervalSeconds,
    isRecurring: !!cronExpression || !!intervalSeconds,
    taskTemplate,
  });

  const id = (result as any).insertId;
  const created = await db
    .select()
    .from(scheduledTasks)
    .where(eq(scheduledTasks.id, id))
    .limit(1);

  return created[0];
}

export async function getScheduledTasks(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(scheduledTasks)
    .where(and(eq(scheduledTasks.userId, userId), eq(scheduledTasks.isEnabled, true)))
    .orderBy(desc(scheduledTasks.createdAt));
}

// Skill queries
export async function createSkill(
  skillName: string,
  skillId: string,
  description?: string,
  userId?: number,
  metadata?: any
): Promise<Skill> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(skills).values({
    skillName,
    skillId,
    description,
    userId,
    metadata,
  });

  const id = (result as any).insertId;
  const created = await db
    .select()
    .from(skills)
    .where(eq(skills.id, id))
    .limit(1);

  return created[0];
}

export async function getSkills(userId?: number) {
  const db = await getDb();
  if (!db) return [];

  if (userId) {
    return db
      .select()
      .from(skills)
      .where(
        and(
          eq(skills.enabled, true),
          or(isNull(skills.userId), eq(skills.userId, userId))
        )
      );
  }

  return db.select().from(skills).where(eq(skills.enabled, true));
}

// Connector queries
export async function createConnector(
  connectorName: string,
  connectorType: string,
  connectorUid: string,
  config?: any,
  credentials?: any,
  userId?: number,
  metadata?: any
): Promise<Connector> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(connectors).values({
    connectorName,
    connectorType,
    connectorUid,
    config,
    credentials,
    userId,
    metadata,
  });

  const id = (result as any).insertId;
  const created = await db
    .select()
    .from(connectors)
    .where(eq(connectors.id, id))
    .limit(1);

  return created[0];
}

export async function getConnectors(userId?: number) {
  const db = await getDb();
  if (!db) return [];

  if (userId) {
    return db
      .select()
      .from(connectors)
      .where(
        and(
          eq(connectors.enabled, true),
          or(isNull(connectors.userId), eq(connectors.userId, userId))
        )
      );
  }

  return db.select().from(connectors).where(eq(connectors.enabled, true));
}

// Tool execution queries
export async function createToolExecution(
  taskId: number,
  toolName: string,
  toolType: string,
  input: any,
  messageId?: number
): Promise<ToolExecution> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(toolExecutions).values({
    taskId,
    toolName,
    toolType,
    input,
    messageId,
  });

  const id = (result as any).insertId;
  const created = await db
    .select()
    .from(toolExecutions)
    .where(eq(toolExecutions.id, id))
    .limit(1);

  return created[0];
}

export async function updateToolExecution(
  executionId: number,
  status: "pending" | "running" | "completed" | "failed",
  output?: string,
  error?: string,
  executionTime?: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updates: any = { status };
  if (output) updates.output = output;
  if (error) updates.error = error;
  if (executionTime) updates.executionTime = executionTime;
  if (status === "completed" || status === "failed") {
    updates.completedAt = new Date();
  }

  return db.update(toolExecutions).set(updates).where(eq(toolExecutions.id, executionId));
}

// Notification queries
export async function createNotification(
  userId: number,
  type: string,
  title: string,
  content?: string,
  actionUrl?: string
): Promise<Notification> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(notifications).values({
    userId,
    type,
    title,
    content,
    actionUrl,
  });

  const id = (result as any).insertId;
  const created = await db
    .select()
    .from(notifications)
    .where(eq(notifications.id, id))
    .limit(1);

  return created[0];
}

export async function getNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
}

// Image generation queries
export async function createImageGeneration(
  userId: number,
  prompt: string,
  conversationId?: number,
  taskId?: number,
  model: string = "dall-e-3"
): Promise<ImageGeneration> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(imageGenerations).values({
    userId,
    prompt,
    conversationId,
    taskId,
    model,
  });

  const id = (result as any).insertId;
  const created = await db
    .select()
    .from(imageGenerations)
    .where(eq(imageGenerations.id, id))
    .limit(1);

  return created[0];
}

export async function updateImageGeneration(
  generationId: number,
  status: "pending" | "completed" | "failed",
  imageUrl?: string,
  fileKey?: string,
  error?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updates: any = { status };
  if (imageUrl) updates.imageUrl = imageUrl;
  if (fileKey) updates.fileKey = fileKey;
  if (error) updates.error = error;
  if (status === "completed" || status === "failed") {
    updates.completedAt = new Date();
  }

  return db
    .update(imageGenerations)
    .set(updates)
    .where(eq(imageGenerations.id, generationId));
}

// Voice transcription queries
export async function createVoiceTranscription(
  userId: number,
  audioUrl: string,
  fileKey?: string,
  conversationId?: number,
  language: string = "en"
): Promise<VoiceTranscription> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(voiceTranscriptions).values({
    userId,
    audioUrl,
    fileKey,
    conversationId,
    language,
  });

  const id = (result as any).insertId;
  const created = await db
    .select()
    .from(voiceTranscriptions)
    .where(eq(voiceTranscriptions.id, id))
    .limit(1);

  return created[0];
}

export async function updateVoiceTranscription(
  transcriptionId: number,
  status: "pending" | "completed" | "failed",
  transcription?: string,
  error?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updates: any = { status };
  if (transcription) updates.transcription = transcription;
  if (error) updates.error = error;
  if (status === "completed" || status === "failed") {
    updates.completedAt = new Date();
  }

  return db
    .update(voiceTranscriptions)
    .set(updates)
    .where(eq(voiceTranscriptions.id, transcriptionId));
}


