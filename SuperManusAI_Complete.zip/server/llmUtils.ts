/**
 * LLM Response Utilities
 * Safely handle LLM response content that can be string or array
 */

export type ContentType = string | any[];

/**
 * Safely extract string content from LLM response
 */
export function extractStringContent(content: ContentType): string {
  if (typeof content === "string") {
    return content;
  }

  if (Array.isArray(content)) {
    // Extract text from content array
    return content
      .map((item) => {
        if (typeof item === "string") return item;
        if (item?.type === "text" && item?.text) return item.text;
        if (item?.text) return item.text;
        return String(item);
      })
      .join("\n");
  }

  return String(content);
}

/**
 * Safely extract content from full LLM response
 */
export function extractLLMContent(response: any): string {
  if (typeof response === "string") return response;

  if (response?.choices?.[0]?.message?.content) {
    return extractStringContent(response.choices[0].message.content);
  }

  if (response?.content) {
    return extractStringContent(response.content);
  }

  return String(response);
}

/**
 * Safely match pattern in content
 */
export function safeMatch(
  content: ContentType,
  pattern: RegExp
): RegExpMatchArray | null {
  const str = extractStringContent(content);
  return str.match(pattern);
}

/**
 * Safely execute regex on content
 */
export function safeExec(
  content: ContentType,
  pattern: RegExp
): RegExpExecArray | null {
  const str = extractStringContent(content);
  return pattern.exec(str);
}

/**
 * Safely search for substring
 */
export function safeIncludes(content: ContentType, searchString: string): boolean {
  const str = extractStringContent(content);
  return str.includes(searchString);
}

/**
 * Safely get substring
 */
export function safeSubstring(
  content: ContentType,
  start: number,
  end?: number
): string {
  const str = extractStringContent(content);
  return str.substring(start, end);
}

/**
 * Safely split content
 */
export function safeSplit(content: ContentType, separator: string): string[] {
  const str = extractStringContent(content);
  return str.split(separator);
}

/**
 * Safely trim content
 */
export function safeTrim(content: ContentType): string {
  const str = extractStringContent(content);
  return str.trim();
}

/**
 * Safely get length
 */
export function safeLength(content: ContentType): number {
  const str = extractStringContent(content);
  return str.length;
}

/**
 * Safely convert to lowercase
 */
export function safeLowerCase(content: ContentType): string {
  const str = extractStringContent(content);
  return str.toLowerCase();
}

/**
 * Safely convert to uppercase
 */
export function safeUpperCase(content: ContentType): string {
  const str = extractStringContent(content);
  return str.toUpperCase();
}
