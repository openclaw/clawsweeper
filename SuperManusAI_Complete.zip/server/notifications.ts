import { notifyOwner } from "./_core/notification";
import * as db from "./db";

/**
 * Owner Notification System
 * Sends notifications to the app owner for important events
 */

/**
 * Notify owner of new user signup
 */
export async function notifyNewSignup(userId: number, userName: string, email: string) {
  try {
    const success = await notifyOwner({
      title: "🎉 New User Signup",
      content: `A new user has joined SuperManus AI!\n\n**Name:** ${userName}\n**Email:** ${email}\n**User ID:** ${userId}\n\nWelcome them to the platform!`,
    });

    if (success) {
      console.log(`[Notifications] Owner notified of new signup: ${userName}`);
    } else {
      console.warn(`[Notifications] Failed to notify owner of new signup`);
    }
  } catch (error) {
    console.error("[Notifications] Error notifying owner of signup:", error);
  }
}

/**
 * Notify owner of task completion
 */
export async function notifyTaskCompletion(
  taskId: number,
  taskTitle: string,
  userName: string,
  result: string
) {
  try {
    const success = await notifyOwner({
      title: "✅ Task Completed",
      content: `A high-priority task has been completed!\n\n**Task:** ${taskTitle}\n**User:** ${userName}\n**Task ID:** ${taskId}\n\n**Result:**\n${result.substring(0, 200)}${result.length > 200 ? "..." : ""}`,
    });

    if (success) {
      console.log(`[Notifications] Owner notified of task completion: ${taskTitle}`);
    } else {
      console.warn(`[Notifications] Failed to notify owner of task completion`);
    }
  } catch (error) {
    console.error("[Notifications] Error notifying owner of task completion:", error);
  }
}

/**
 * Notify owner of task failure
 */
export async function notifyTaskFailure(
  taskId: number,
  taskTitle: string,
  userName: string,
  error: string
) {
  try {
    const success = await notifyOwner({
      title: "❌ Task Failed",
      content: `A task has failed and requires attention!\n\n**Task:** ${taskTitle}\n**User:** ${userName}\n**Task ID:** ${taskId}\n\n**Error:**\n${error.substring(0, 200)}${error.length > 200 ? "..." : ""}`,
    });

    if (success) {
      console.log(`[Notifications] Owner notified of task failure: ${taskTitle}`);
    } else {
      console.warn(`[Notifications] Failed to notify owner of task failure`);
    }
  } catch (error) {
    console.error("[Notifications] Error notifying owner of task failure:", error);
  }
}

/**
 * Notify owner of high-priority task
 */
export async function notifyHighPriorityTask(
  taskId: number,
  taskTitle: string,
  userName: string,
  priority: string
) {
  try {
    const success = await notifyOwner({
      title: "🔴 High-Priority Task",
      content: `A high-priority task has been created!\n\n**Task:** ${taskTitle}\n**Priority:** ${priority.toUpperCase()}\n**User:** ${userName}\n**Task ID:** ${taskId}\n\nPlease review and monitor this task.`,
    });

    if (success) {
      console.log(`[Notifications] Owner notified of high-priority task: ${taskTitle}`);
    } else {
      console.warn(`[Notifications] Failed to notify owner of high-priority task`);
    }
  } catch (error) {
    console.error("[Notifications] Error notifying owner of high-priority task:", error);
  }
}

/**
 * Notify owner of system events
 */
export async function notifySystemEvent(title: string, content: string) {
  try {
    const success = await notifyOwner({ title, content });

    if (success) {
      console.log(`[Notifications] Owner notified of system event: ${title}`);
    } else {
      console.warn(`[Notifications] Failed to notify owner of system event`);
    }
  } catch (error) {
    console.error("[Notifications] Error notifying owner of system event:", error);
  }
}

/**
 * Create notification record in database
 */
export async function createNotification(
  userId: number,
  title: string,
  content: string,
  type: "info" | "success" | "warning" | "error" = "info"
) {
  try {
    return await db.createNotification(userId, title, content, type);
  } catch (error) {
    console.error("[Notifications] Error creating notification record:", error);
  }
}

/**
 * Send batch notifications
 */
export async function sendBatchNotifications(
  notifications: Array<{
    userId: number;
    title: string;
    content: string;
    type?: "info" | "success" | "warning" | "error";
  }>
) {
  try {
    const results = await Promise.all(
      notifications.map((notif) =>
        createNotification(notif.userId, notif.title, notif.content, notif.type)
      )
    );

    console.log(`[Notifications] Sent ${results.length} batch notifications`);
    return results;
  } catch (error) {
    console.error("[Notifications] Error sending batch notifications:", error);
  }
}
