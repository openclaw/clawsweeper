import { invokeLLM } from "./_core/llm";
import {
  extractLLMContent,
  safeMatch,
  safeTrim,
  safeLowerCase,
  safeExec,
  safeSubstring,
  safeIncludes,
} from "./llmUtils";

/**
 * Ultra-Powerful Reasoning Engine for SuperManus AI
 * Implements advanced reasoning patterns including:
 * - Chain-of-Thought (CoT) decomposition
 * - Multi-path exploration and evaluation
 * - Socratic questioning and self-critique
 * - Recursive problem decomposition
 * - Hypothesis generation and testing
 */

export interface ReasoningPath {
  pathId: string;
  steps: ReasoningStep[];
  confidence: number;
  conclusion: string;
  evidence: string[];
}

export interface ReasoningStep {
  stepId: string;
  type: "observation" | "hypothesis" | "deduction" | "inference" | "critique" | "synthesis";
  content: string;
  reasoning: string;
  alternatives?: string[];
  confidence: number;
}

export interface UltraPowerfulReasoningResult {
  primaryPath: ReasoningPath;
  alternativePaths: ReasoningPath[];
  synthesis: string;
  confidence: number;
  criticalAssumptions: string[];
  potentialFlaws: string[];
  recommendations: string[];
}

/**
 * Ultra-powerful reasoning with multi-path exploration
 */
export async function ultraPowerfulReasoning(
  problem: string,
  context: string = "",
  maxPaths: number = 3
): Promise<UltraPowerfulReasoningResult> {
  // Phase 1: Problem decomposition
  const decomposition = await decomposeProbl(problem, context);

  // Phase 2: Multi-path exploration
  const paths = await exploreMultiplePaths(problem, decomposition, maxPaths);

  // Phase 3: Path evaluation and ranking
  const rankedPaths = await evaluateAndRankPaths(paths);

  // Phase 4: Synthesis and meta-reasoning
  const synthesis = await synthesizePaths(rankedPaths, problem);

  // Phase 5: Critical analysis
  const criticalAnalysis = await performCriticalAnalysis(
    rankedPaths,
    synthesis.conclusion,
    problem
  );

  return {
    primaryPath: rankedPaths[0],
    alternativePaths: rankedPaths.slice(1),
    synthesis: synthesis.conclusion,
    confidence: synthesis.confidence,
    criticalAssumptions: criticalAnalysis.assumptions,
    potentialFlaws: criticalAnalysis.flaws,
    recommendations: criticalAnalysis.recommendations,
  };
}

/**
 * Decompose problem into sub-problems
 */
async function decomposeProbl(problem: string, context: string): Promise<string[]> {
  const systemPrompt = `You are an expert problem decomposer. Break down complex problems into smaller, manageable sub-problems.
Format your response as a JSON array of sub-problems.
Example: ["Sub-problem 1: ...", "Sub-problem 2: ...", "Sub-problem 3: ..."]`;

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: systemPrompt,
      },
      {
        role: "user",
        content: `Problem: ${problem}\nContext: ${context}`,
      },
    ],
  });

  try {
    const content = extractLLMContent(response);
    const jsonMatch = content.match(/\[[\s\S]*\]/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
  } catch (error) {
    console.error("Failed to parse decomposition:", error);
  }

  return [problem];
}

/**
 * Explore multiple reasoning paths
 */
async function exploreMultiplePaths(
  problem: string,
  subProblems: string[],
  maxPaths: number
): Promise<ReasoningPath[]> {
  const paths: ReasoningPath[] = [];

  // Generate multiple reasoning approaches
  const approaches = [
    "analytical",
    "creative",
    "empirical",
    "theoretical",
    "practical",
  ].slice(0, maxPaths);

  for (const approach of approaches) {
    const path = await generateReasoningPath(problem, subProblems, approach);
    paths.push(path);
  }

  return paths;
}

/**
 * Generate a single reasoning path with specific approach
 */
async function generateReasoningPath(
  problem: string,
  subProblems: string[],
  approach: string
): Promise<ReasoningPath> {
  const systemPrompt = `You are an expert reasoner using the ${approach} approach.
Think step-by-step through this problem. For each step:
1. State your observation or hypothesis
2. Explain your reasoning
3. Consider alternatives
4. Rate your confidence (0-1)

Format as JSON with steps array and final conclusion.`;

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: systemPrompt,
      },
      {
        role: "user",
        content: `Problem: ${problem}\n\nSub-problems:\n${subProblems.join("\n")}`,
      },
    ],
  });

  const content = extractLLMContent(response);

  // Parse response into reasoning steps
  const steps = parseReasoningSteps(content);
  const conclusion = extractConclusion(content);
  const evidence = extractEvidence(content);
  const confidence = calculateConfidence(steps);

  return {
    pathId: `path-${approach}-${Date.now()}`,
    steps,
    confidence,
    conclusion,
    evidence,
  };
}

/**
 * Parse reasoning steps from response
 */
function parseReasoningSteps(content: string): ReasoningStep[] {
  const steps: ReasoningStep[] = [];
  let stepNumber = 1;

  // Extract step patterns
  const stepPattern =
    /(?:step|observation|hypothesis|deduction|inference|critique)[\s:]*([^\n]+)/gi;
  let match;

  while ((match = safeExec(content, stepPattern)) !== null) {
    steps.push({
      stepId: `step-${stepNumber}`,
      type: inferStepType(match[0]),
      content: match[1].trim(),
      reasoning: extractReasoningForStep(content, match[1]),
      confidence: 0.8,
    });
    stepNumber++;
  }

  return steps;
}

/**
 * Infer step type from content
 */
function inferStepType(
  content: string
): "observation" | "hypothesis" | "deduction" | "inference" | "critique" | "synthesis" {
  const lower = safeLowerCase(content);
  if (safeIncludes(lower, "observe") || safeIncludes(lower, "notice"))
    return "observation";
  if (safeIncludes(lower, "hypothesis") || safeIncludes(lower, "assume"))
    return "hypothesis";
  if (safeIncludes(lower, "deduce") || safeIncludes(lower, "conclude"))
    return "deduction";
  if (safeIncludes(lower, "infer")) return "inference";
  if (safeIncludes(lower, "critique") || safeIncludes(lower, "question"))
    return "critique";
  return "synthesis";
}

/**
 * Extract reasoning explanation for a step
 */
function extractReasoningForStep(content: string, step: string): string {
  const stepIndex = content.indexOf(step);
  if (stepIndex === -1) return "";

  // Get next 300 characters as reasoning
  return safeTrim(safeSubstring(content, stepIndex, stepIndex + 300));
}

/**
 * Extract conclusion from response
 */
function extractConclusion(content: string): string {
  const conclusionMatch = safeMatch(
    content,
    /(?:conclusion|final answer|result):\s*([\s\S]*?)(?=\n\n|$)/i
  );
  return conclusionMatch ? safeTrim(conclusionMatch[1]) : safeSubstring(content, 0, 500);
}

/**
 * Extract evidence from response
 */
function extractEvidence(content: string): string[] {
  const evidence: string[] = [];
  const evidencePattern = /(?:evidence|support|reason):\s*([^\n]+)/gi;
  let match;

  while ((match = safeExec(content, evidencePattern)) !== null) {
    evidence.push(safeTrim(match[1]));
  }

  return evidence;
}

/**
 * Calculate overall confidence from steps
 */
function calculateConfidence(steps: ReasoningStep[]): number {
  if (steps.length === 0) return 0.5;
  const avgConfidence =
    steps.reduce((sum, step) => sum + step.confidence, 0) / steps.length;
  return Math.min(avgConfidence, 1);
}

/**
 * Evaluate and rank reasoning paths
 */
async function evaluateAndRankPaths(paths: ReasoningPath[]): Promise<ReasoningPath[]> {
  const systemPrompt = `You are an expert evaluator of reasoning paths.
Evaluate each path on:
1. Logical consistency (0-1)
2. Evidence quality (0-1)
3. Completeness (0-1)
4. Practicality (0-1)

Return a JSON array with scores for each path.`;

  const pathSummaries = paths.map((p) => ({
    id: p.pathId,
    conclusion: p.conclusion,
    steps: p.steps.length,
    evidence: p.evidence.length,
  }));

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: systemPrompt,
      },
      {
        role: "user",
        content: `Evaluate these reasoning paths:\n${JSON.stringify(pathSummaries, null, 2)}`,
      },
    ],
  });

  const content = extractLLMContent(response);

  // Parse scores and adjust path confidence
  const scores = parseEvaluationScores(content, paths.length);
  paths.forEach((path, index) => {
    if (scores[index]) {
      path.confidence = scores[index];
    }
  });

  // Sort by confidence (descending)
  return paths.sort((a, b) => b.confidence - a.confidence);
}

/**
 * Parse evaluation scores from response
 */
function parseEvaluationScores(content: string, pathCount: number): number[] {
  const scores: number[] = [];
  const scorePattern = /(?:score|rating)[\s:]*([0-9.]+)/gi;
  let match;

  while ((match = safeExec(content, scorePattern)) !== null && scores.length < pathCount) {
    const score = parseFloat(match[1]);
    if (!isNaN(score)) {
      scores.push(Math.min(score, 1));
    }
  }

  // Fill missing scores with default
  while (scores.length < pathCount) {
    scores.push(0.5);
  }

  return scores.slice(0, pathCount);
}

/**
 * Synthesize multiple paths into unified conclusion
 */
async function synthesizePaths(
  paths: ReasoningPath[],
  problem: string
): Promise<{ conclusion: string; confidence: number }> {
  const systemPrompt = `You are an expert synthesizer of multiple reasoning approaches.
Combine the best insights from all paths into a unified, coherent conclusion.
Consider where paths agree and where they diverge.
Highlight the most robust conclusion supported by multiple approaches.`;

  const pathSummaries = paths.map((p) => ({
    approach: p.pathId,
    conclusion: p.conclusion,
    confidence: p.confidence,
    evidence: p.evidence.slice(0, 3),
  }));

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: systemPrompt,
      },
      {
        role: "user",
        content: `Problem: ${problem}\n\nReasoning paths:\n${JSON.stringify(pathSummaries, null, 2)}`,
      },
    ],
  });

  const content = extractLLMContent(response);
  const conclusion = extractConclusion(content);
  const confidence = paths.reduce((sum, p) => sum + p.confidence, 0) / paths.length;

  return { conclusion, confidence };
}

/**
 * Perform critical analysis on reasoning
 */
async function performCriticalAnalysis(
  paths: ReasoningPath[],
  synthesis: string,
  problem: string
): Promise<{
  assumptions: string[];
  flaws: string[];
  recommendations: string[];
}> {
  const systemPrompt = `You are a critical thinking expert.
Analyze the reasoning for:
1. Hidden assumptions
2. Potential logical flaws
3. Missing considerations
4. Recommendations for improvement

Format as JSON with assumptions, flaws, and recommendations arrays.`;

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: systemPrompt,
      },
      {
        role: "user",
        content: `Problem: ${problem}\n\nSynthesis: ${synthesis}\n\nPaths analyzed: ${paths.length}`,
      },
    ],
  });

  const content = extractLLMContent(response);

  return {
    assumptions: extractListItems(content, "assumption"),
    flaws: extractListItems(content, "flaw"),
    recommendations: extractListItems(content, "recommendation"),
  };
}

/**
 * Extract list items from response
 */
function extractListItems(content: string, itemType: string): string[] {
  const items: string[] = [];
  const pattern = new RegExp(`(?:${itemType}|issue|point)\\s*[:\\-]*\\s*([^\\n]+)`, "gi");
  let match;

  while ((match = safeExec(content, pattern)) !== null) {
    items.push(safeTrim(match[1]));
  }

  return items;
}

/**
 * Socratic questioning for deeper reasoning
 */
export async function socraticQuestioning(
  statement: string,
  depth: number = 3
): Promise<string[]> {
  const questions: string[] = [];

  for (let i = 0; i < depth; i++) {
    const systemPrompt = `You are a Socratic questioner. Ask probing questions that challenge assumptions and deepen understanding.
Ask exactly 1 powerful question that builds on previous insights.`;

    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: systemPrompt,
        },
        {
          role: "user",
          content: `Statement: ${statement}\n\nPrevious questions: ${questions.join("\n")}`,
        },
      ],
    });

    const question = extractLLMContent(response);
    if (question) {
      questions.push(safeTrim(question));
    }
  }

  return questions;
}

/**
 * Hypothesis generation and testing
 */
export async function generateAndTestHypotheses(
  problem: string,
  context: string
): Promise<{ hypothesis: string; likelihood: number; evidence: string[] }[]> {
  const systemPrompt = `You are a hypothesis generator and tester.
Generate 3-5 plausible hypotheses that could explain the problem.
For each, assess likelihood and supporting evidence.

Format as JSON array with hypothesis, likelihood (0-1), and evidence array.`;

  const response = await invokeLLM({
    messages: [
      {
        role: "system",
        content: systemPrompt,
      },
      {
        role: "user",
        content: `Problem: ${problem}\nContext: ${context}`,
      },
    ],
  });

  const content = extractLLMContent(response);

  try {
    const jsonMatch = content.match(/\[[\s\S]*\]/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
  } catch (error) {
    console.error("Failed to parse hypotheses:", error);
  }

  return [];
}
