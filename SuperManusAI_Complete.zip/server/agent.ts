import { invokeLLM } from "./_core/llm";
import { generateImage } from "./_core/imageGeneration";
import { transcribeAudio } from "./_core/voiceTranscription";
import { extractLLMContent, safeMatch, safeTrim, safeLowerCase } from "./llmUtils";

/**
 * Agent Engine for SuperManus AI
 * Supports Granite 4 (powerful reasoning) and Nemotron (fast inference)
 */

export type ModelType = "granite-4" | "nemotron";
export type ToolType = "web_search" | "code_execution" | "file_io" | "data_analysis" | "image_generation" | "voice_transcription";

export interface AgentMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

export interface AgentReasoningStep {
  stepNumber: number;
  stepType: "planning" | "reasoning" | "tool_call" | "decision" | "reflection";
  content: string;
  status: "pending" | "active" | "completed";
}

export interface AgentToolCall {
  toolName: string;
  toolType: ToolType;
  input: Record<string, any>;
  result?: string;
  error?: string;
}

export interface AgentResponse {
  content: string;
  reasoning: string;
  toolCalls: AgentToolCall[];
  reasoningSteps: AgentReasoningStep[];
  model: ModelType;
  tokens: {
    input: number;
    output: number;
  };
}

/**
 * Get the system prompt based on model type
 */
function getSystemPrompt(model: ModelType): string {
  const basePrompt = `You are SuperManus AI, an advanced autonomous agent designed to help users accomplish complex tasks through multi-step reasoning and tool integration.

Core Principles:
1. Clarity & Directness: Lead with the answer. Be concise when possible, expansive when needed.
2. Self-Improvement: Proactively suggest refinements and better approaches.
3. Adaptability: Adjust tone, depth, and format instantly based on user context.
4. Truth-Seeking: Prioritize accuracy. If uncertain, state it clearly.

Available Tools:
- web_search: Search the internet for information
- code_execution: Execute Python code safely
- file_io: Read and write files
- data_analysis: Analyze data and create visualizations
- image_generation: Generate images from text descriptions
- voice_transcription: Convert speech to text

When using tools, always explain your reasoning before and after tool invocation.
Format your response with clear sections for reasoning, tool calls, and results.`;

  if (model === "granite-4") {
    return (
      basePrompt +
      `

Model: Granite 4 (Powerful Reasoning)
- Use for complex multi-step reasoning tasks
- Leverage for strategic planning and analysis
- Employ for tasks requiring deep understanding
- Optimal for code generation and debugging`
    );
  }

  return (
    basePrompt +
    `

Model: Nemotron (Fast & Efficient)
- Use for quick responses and straightforward tasks
- Leverage for real-time interactions
- Optimal for conversational exchanges
- Ideal for rapid prototyping and iteration`
  );
}

/**
 * Invoke the agent with a user message
 */
export async function invokeAgent(
  userMessage: string,
  conversationHistory: AgentMessage[],
  model: ModelType = "nemotron",
  tools: ToolType[] = []
): Promise<AgentResponse> {
  const systemPrompt = getSystemPrompt(model);

  // Build message history
  const messages: AgentMessage[] = [
    { role: "system", content: systemPrompt },
    ...conversationHistory,
    { role: "user", content: userMessage },
  ];

  // Invoke the LLM
  const response = await invokeLLM({
    messages: messages.map((m) => ({
      role: m.role,
      content: m.content,
    })),
  });

  // Parse response
  const content = extractLLMContent(response);

  // Extract reasoning and tool calls from response
  const reasoning = extractReasoning(content);
  const toolCalls = extractToolCalls(content);
  const reasoningSteps = generateReasoningSteps(content);

  return {
    content,
    reasoning,
    toolCalls,
    reasoningSteps,
    model,
    tokens: {
      input: response.usage?.prompt_tokens || 0,
      output: response.usage?.completion_tokens || 0,
    },
  };
}

/**
 * Execute a tool based on its type
 */
export async function executeTool(
  toolType: ToolType,
  input: Record<string, any>
): Promise<string> {
  switch (toolType) {
    case "web_search":
      return executeWebSearch(input);
    case "code_execution":
      return executeCode(input);
    case "file_io":
      return executeFileIO(input);
    case "data_analysis":
      return executeDataAnalysis(input);
    case "image_generation":
      return executeImageGeneration(input);
    case "voice_transcription":
      return executeVoiceTranscription(input);
    default:
      throw new Error(`Unknown tool type: ${toolType}`);
  }
}

/**
 * Web search tool
 */
async function executeWebSearch(input: Record<string, any>): Promise<string> {
  const query = input.query || "";
  if (!query) throw new Error("Query is required for web search");

  // TODO: Implement web search integration
  return `Search results for: ${query}`;
}

/**
 * Code execution tool
 */
async function executeCode(input: Record<string, any>): Promise<string> {
  const code = input.code || "";
  if (!code) throw new Error("Code is required for execution");

  // TODO: Implement safe code execution sandbox
  return `Code execution result: ${code}`;
}

/**
 * File I/O tool
 */
async function executeFileIO(input: Record<string, any>): Promise<string> {
  const operation = input.operation || "read";
  const path = input.path || "";

  if (!path) throw new Error("Path is required for file operations");

  // TODO: Implement file I/O with security checks
  return `File operation (${operation}) on: ${path}`;
}

/**
 * Data analysis tool
 */
async function executeDataAnalysis(input: Record<string, any>): Promise<string> {
  const data = input.data || [];
  const analysisType = input.type || "summary";

  // TODO: Implement data analysis with visualization
  return `Data analysis (${analysisType}) completed`;
}

/**
 * Image generation tool
 */
async function executeImageGeneration(input: Record<string, any>): Promise<string> {
  const prompt = input.prompt || "";
  if (!prompt) throw new Error("Prompt is required for image generation");

  try {
    const result = await generateImage({ prompt });
    return `Image generated: ${result.url}`;
  } catch (error) {
    throw new Error(`Image generation failed: ${error}`);
  }
}

/**
 * Voice transcription tool
 */
async function executeVoiceTranscription(input: Record<string, any>): Promise<string> {
  const audioUrl = input.audioUrl || "";
  const language = input.language || "en";

  if (!audioUrl) throw new Error("Audio URL is required for transcription");

  try {
    const result = await transcribeAudio({
      audioUrl,
      language,
    });
    const text = (result as any)?.text || String(result);
    return `Transcription: ${text}`;
  } catch (error) {
    throw new Error(`Transcription failed: ${error}`);
  }
}

/**
 * Extract reasoning from response
 */
function extractReasoning(content: string): string {
  // Look for reasoning section markers
  const reasoningMatch = safeMatch(
    content,
    /(?:reasoning|thought process|analysis):\s*([\s\S]*?)(?=\n\n|tool calls|result|$)/i
  );
  return reasoningMatch ? safeTrim(reasoningMatch[1]) : "";
}

/**
 * Extract tool calls from response
 */
function extractToolCalls(content: string): AgentToolCall[] {
  const toolCalls: AgentToolCall[] = [];

  // Look for tool call patterns
  const toolPattern = /tool:\s*(\w+)\s*(?:input|params)?:\s*([\s\S]*?)(?=\n\ntool:|result:|$)/gi;
  let match;

  while ((match = toolPattern.exec(content)) !== null) {
    const toolName = match[1];
    const inputStr = match[2];

    try {
      const input = JSON.parse(inputStr);
      toolCalls.push({
        toolName,
        toolType: toolName as ToolType,
        input,
      });
    } catch {
      // If JSON parsing fails, treat as string input
      toolCalls.push({
        toolName,
        toolType: toolName as ToolType,
        input: { query: inputStr },
      });
    }
  }

  return toolCalls;
}

/**
 * Generate reasoning steps from response
 */
function generateReasoningSteps(content: string): AgentReasoningStep[] {
  const steps: AgentReasoningStep[] = [];
  let stepNumber = 1;

  // Extract planning phase
  if (content.toLowerCase().includes("plan") || content.toLowerCase().includes("step")) {
    steps.push({
      stepNumber: stepNumber++,
      stepType: "planning",
      content: "Analyzing task requirements and planning approach",
      status: "completed",
    });
  }

  // Extract reasoning phase
  if (content.toLowerCase().includes("reason") || content.toLowerCase().includes("think")) {
    steps.push({
      stepNumber: stepNumber++,
      stepType: "reasoning",
      content: "Reasoning through the problem",
      status: "completed",
    });
  }

  // Extract tool calls
  if (content.toLowerCase().includes("tool") || content.toLowerCase().includes("search")) {
    steps.push({
      stepNumber: stepNumber++,
      stepType: "tool_call",
      content: "Executing tools to gather information",
      status: "completed",
    });
  }

  // Extract decision phase
  if (content.toLowerCase().includes("decide") || content.toLowerCase().includes("conclude")) {
    steps.push({
      stepNumber: stepNumber++,
      stepType: "decision",
      content: "Making decisions based on analysis",
      status: "completed",
    });
  }

  // If no steps detected, create a default one
  if (steps.length === 0) {
    steps.push({
      stepNumber: 1,
      stepType: "reasoning",
      content: content.substring(0, 200),
      status: "completed",
    });
  }

  return steps;
}

/**
 * Stream agent response (for real-time updates)
 */
export async function streamAgentResponse(
  userMessage: string,
  conversationHistory: AgentMessage[],
  model: ModelType = "nemotron",
  onChunk?: (chunk: string) => void
): Promise<AgentResponse> {
  // TODO: Implement streaming response handling
  return invokeAgent(userMessage, conversationHistory, model);
}
