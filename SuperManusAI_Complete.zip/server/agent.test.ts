import { describe, it, expect, vi, beforeEach } from "vitest";
import { invokeAgent, extractReasoningFromResponse } from "./agent";
import { executeTool } from "./tools";
import { ultraPowerfulReasoning } from "./reasoning";

describe("Agent Engine", () => {
  describe("invokeAgent", () => {
    it("should invoke agent with user message", async () => {
      const response = await invokeAgent(
        "What is 2 + 2?",
        [{ role: "user", content: "What is 2 + 2?" }],
        "nemotron-4b",
        []
      );

      expect(response).toBeDefined();
      expect(response.content).toBeDefined();
      expect(response.content.length).toBeGreaterThan(0);
    });

    it("should handle conversation history", async () => {
      const messages = [
        { role: "user" as const, content: "Hello" },
        { role: "assistant" as const, content: "Hi there!" },
        { role: "user" as const, content: "How are you?" },
      ];

      const response = await invokeAgent("How are you?", messages, "nemotron-4b", []);

      expect(response).toBeDefined();
      expect(response.content).toBeDefined();
    });

    it("should support both models", async () => {
      const nemotronResponse = await invokeAgent(
        "Test",
        [{ role: "user", content: "Test" }],
        "nemotron-4b",
        []
      );

      const graniteResponse = await invokeAgent(
        "Test",
        [{ role: "user", content: "Test" }],
        "granite-4",
        []
      );

      expect(nemotronResponse).toBeDefined();
      expect(graniteResponse).toBeDefined();
    });
  });

  describe("extractReasoningFromResponse", () => {
    it("should extract reasoning from response", () => {
      const response = {
        choices: [
          {
            message: {
              content: "Let me think about this step by step...",
            },
          },
        ],
      };

      const reasoning = extractReasoningFromResponse(response);
      expect(reasoning).toBeDefined();
    });

    it("should handle missing reasoning", () => {
      const response = {
        choices: [
          {
            message: {
              content: "Simple answer",
            },
          },
        ],
      };

      const reasoning = extractReasoningFromResponse(response);
      expect(reasoning).toBeDefined();
    });
  });
});

describe("Tool System", () => {
  describe("executeTool", () => {
    it("should execute web search tool", async () => {
      const result = await executeTool("web_search", {
        query: "artificial intelligence",
      });

      expect(result).toBeDefined();
      expect(result.toolName).toBe("web_search");
      expect(result.status).toBe("success" || "error");
    });

    it("should execute code execution tool", async () => {
      const result = await executeTool("code_execution", {
        code: "print('Hello, World!')",
        language: "python",
      });

      expect(result).toBeDefined();
      expect(result.toolName).toBe("code_execution");
    });

    it("should execute data analysis tool", async () => {
      const result = await executeTool("data_analysis", {
        data: { values: [1, 2, 3, 4, 5] },
        analysisType: "statistical",
      });

      expect(result).toBeDefined();
      expect(result.toolName).toBe("data_analysis");
    });

    it("should handle unknown tools", async () => {
      const result = await executeTool("unknown_tool", {});

      expect(result.status).toBe("error");
      expect(result.result).toContain("Unknown tool");
    });
  });
});

describe("Reasoning Engine", () => {
  describe("ultraPowerfulReasoning", () => {
    it("should perform ultra-powerful reasoning", async () => {
      const result = await ultraPowerfulReasoning(
        "How can we improve code quality?",
        "We have a large codebase with technical debt"
      );

      expect(result).toBeDefined();
      expect(result.primaryPath).toBeDefined();
      expect(result.synthesis).toBeDefined();
      expect(result.confidence).toBeGreaterThan(0);
      expect(result.confidence).toBeLessThanOrEqual(1);
    });

    it("should generate multiple reasoning paths", async () => {
      const result = await ultraPowerfulReasoning(
        "What is the best approach to system design?",
        "",
        3
      );

      expect(result.primaryPath).toBeDefined();
      expect(result.alternativePaths).toBeDefined();
      expect(result.alternativePaths.length).toBeGreaterThanOrEqual(0);
    });

    it("should identify critical assumptions", async () => {
      const result = await ultraPowerfulReasoning(
        "Should we migrate to microservices?",
        "Current monolithic architecture"
      );

      expect(result.criticalAssumptions).toBeDefined();
      expect(Array.isArray(result.criticalAssumptions)).toBe(true);
    });

    it("should identify potential flaws", async () => {
      const result = await ultraPowerfulReasoning(
        "What is the best database for our use case?",
        "High volume, real-time data"
      );

      expect(result.potentialFlaws).toBeDefined();
      expect(Array.isArray(result.potentialFlaws)).toBe(true);
    });

    it("should provide recommendations", async () => {
      const result = await ultraPowerfulReasoning(
        "How to improve team productivity?",
        "Remote team, async communication"
      );

      expect(result.recommendations).toBeDefined();
      expect(Array.isArray(result.recommendations)).toBe(true);
    });
  });
});

describe("Agent Integration", () => {
  it("should handle complex multi-step reasoning", async () => {
    const response = await invokeAgent(
      "Analyze the pros and cons of using TypeScript in a large project",
      [
        {
          role: "user",
          content: "Analyze the pros and cons of using TypeScript in a large project",
        },
      ],
      "granite-4",
      []
    );

    expect(response.content).toBeDefined();
    expect(response.reasoning).toBeDefined();
  });

  it("should maintain context across messages", async () => {
    const messages = [
      { role: "user" as const, content: "What is machine learning?" },
      {
        role: "assistant" as const,
        content: "Machine learning is a subset of AI...",
      },
      {
        role: "user" as const,
        content: "Can you give me an example?",
      },
    ];

    const response = await invokeAgent(
      "Can you give me an example?",
      messages,
      "nemotron-4b",
      []
    );

    expect(response.content).toBeDefined();
  });
});
