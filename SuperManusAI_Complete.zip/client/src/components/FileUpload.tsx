import { useState, useRef } from "react";
import { motion } from "framer-motion";
import { Upload, File, X, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { trpc } from "@/lib/trpc";

interface FileUploadProps {
  conversationId: number;
  onFileUploaded?: (fileId: number) => void;
}

export default function FileUpload({ conversationId, onFileUploaded }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filesQuery = trpc.files.list.useQuery({ conversationId });
  const uploadMutation = trpc.files.upload.useMutation({
    onSuccess: (file: any) => {
      setUploadedFiles((prev: any[]) => [...prev, file]);
      setUploadProgress(0);
      setUploading(false);
      onFileUploaded?.(file.id);
      filesQuery.refetch();
    },
    onError: () => {
      setUploading(false);
      setUploadProgress(0);
    },
  });

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      handleFiles(files);
    }
  };

  const handleFiles = async (files: File[]) => {
    for (const file of files) {
      setUploading(true);
      setUploadProgress(0);

      try {
        // Simulate progress
        const progressInterval = setInterval(() => {
          setUploadProgress((prev) => Math.min(prev + 10, 90));
        }, 100);

        // Upload file to storage
        const formData = new FormData();
        formData.append("file", file);

        // In a real implementation, this would upload to S3 via the backend
        // For now, we'll create a file record
        uploadMutation.mutate({
          filename: file.name,
          mimeType: file.type,
          fileKey: `files/${Date.now()}-${file.name}`,
          fileSize: file.size,
          conversationId,
        });

        clearInterval(progressInterval);
        setUploadProgress(100);
      } catch (error) {
        console.error("Upload failed:", error);
        setUploading(false);
        setUploadProgress(0);
      }
    }
  };

  return (
    <div className="space-y-4">
      {/* Upload Area */}
      <motion.div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-lg p-6 text-center transition-all ${
          isDragging
            ? "border-cyan-400 bg-cyan-500/10"
            : "border-purple-500/30 bg-slate-800/50 hover:border-purple-500/50"
        }`}
        animate={{ scale: isDragging ? 1.02 : 1 }}
      >
        <Upload className="w-8 h-8 mx-auto mb-3 text-purple-400" />
        <p className="text-sm font-medium text-white mb-1">Drag files here or click to upload</p>
        <p className="text-xs text-purple-300/60 mb-4">Supported: Images, Documents, Code, Data</p>

        <input
          ref={fileInputRef}
          type="file"
          multiple
          onChange={handleFileSelect}
          className="hidden"
          accept="*/*"
        />

        <Button
          variant="outline"
          size="sm"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
        >
          Choose Files
        </Button>
      </motion.div>

      {/* Upload Progress */}
      {uploading && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-800/50 border border-purple-500/30 rounded-lg p-4"
        >
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-medium text-white">Uploading...</p>
            <p className="text-xs text-purple-300/60">{uploadProgress}%</p>
          </div>
          <Progress value={uploadProgress} className="h-2" />
        </motion.div>
      )}

      {/* Uploaded Files */}
      {filesQuery.data && filesQuery.data.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-2"
        >
          <p className="text-sm font-medium text-purple-300/60">Files in Conversation</p>
          {filesQuery.data.map((file) => (
            <motion.div
              key={file.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-3 p-3 bg-slate-800/50 border border-purple-500/20 rounded-lg hover:border-purple-500/50 transition-all"
            >
              <File className="w-4 h-4 text-cyan-400 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-white truncate">{file.filename}</p>
                <p className="text-xs text-purple-300/60">
                  {(file.fileSize || 0) > 1024 * 1024
                    ? `${((file.fileSize || 0) / (1024 * 1024)).toFixed(2)} MB`
                    : `${((file.fileSize || 0) / 1024).toFixed(2)} KB`}
                </p>
              </div>
              <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  );
}
