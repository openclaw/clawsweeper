import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Streamdown } from "streamdown";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Spinner } from "@/components/ui/spinner";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Zap, Brain, Clock } from "lucide-react";
import { trpc } from "@/lib/trpc";

export interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  reasoning?: string | null;
  toolCalls?: any[] | null;
  reasoningSteps?: any[] | null;
  createdAt: Date;
}

interface ChatInterfaceProps {
  conversationId: number;
  model: "nemotron-4b" | "granite-4";
  onModelChange: (model: "nemotron-4b" | "granite-4") => void;
}

export default function ChatInterface({
  conversationId,
  model,
  onModelChange,
}: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [showReasoning, setShowReasoning] = useState(false);
  const [selectedReasoningMessage, setSelectedReasoningMessage] = useState<number | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const messagesQuery = trpc.messages.list.useQuery({ conversationId });
  const sendMessageMutation = trpc.messages.send.useMutation({
    onSuccess: (data) => {
      setMessages((prev) => [
        ...prev,
        {
          id: data.userMessage.id,
          role: "user" as const,
          content: data.userMessage.content,
          createdAt: new Date(data.userMessage.createdAt),
        },
        {
          id: data.assistantMessage.id,
          role: "assistant" as const,
          content: data.assistantMessage.content,
          reasoning: data.reasoning || undefined,
          toolCalls: Array.isArray(data.toolCalls) ? data.toolCalls : undefined,
          reasoningSteps: Array.isArray(data.reasoningSteps) ? data.reasoningSteps : undefined,
          createdAt: new Date(data.assistantMessage.createdAt),
        },
      ]);
      setInput("");
    },
  });

  useEffect(() => {
    if (messagesQuery.data) {
    setMessages(
      messagesQuery.data.map((msg) => ({
        id: msg.id,
        role: msg.role as "user" | "assistant",
        content: msg.content,
        reasoning: msg.reasoning || undefined,
        toolCalls: Array.isArray(msg.toolCalls) ? msg.toolCalls : undefined,
        reasoningSteps: (msg as any).reasoningSteps || undefined,
        createdAt: new Date(msg.createdAt),
      }))
    );
    }
  }, [messagesQuery.data]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleSendMessage = () => {
    if (!input.trim()) return;

    sendMessageMutation.mutate({
      conversationId,
      content: input,
      model,
    });
  };

  return (
    <div className="flex flex-col h-full bg-slate-950/50">
      {/* Header with Model Selector */}
      <div className="border-b border-purple-500/20 p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 bg-cyan-400 rounded-full animate-pulse" />
          <span className="text-sm font-medium text-purple-300">Active Model</span>
        </div>
        <div className="flex gap-2">
          <Button
            variant={model === "nemotron-4b" ? "default" : "outline"}
            size="sm"
            onClick={() => onModelChange("nemotron-4b")}
            className="text-xs"
          >
            <Zap className="w-3 h-3 mr-1" />
            Nemotron 4B
          </Button>
          <Button
            variant={model === "granite-4" ? "default" : "outline"}
            size="sm"
            onClick={() => onModelChange("granite-4")}
            className="text-xs"
          >
            <Brain className="w-3 h-3 mr-1" />
            Granite 4
          </Button>
        </div>
      </div>

      {/* Messages Area */}
      <ScrollArea className="flex-1 p-6">
        <div className="space-y-6 max-w-4xl">
          <AnimatePresence>
            {messages.map((message, idx) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-2xl ${
                    message.role === "user"
                      ? "bg-purple-600/30 border border-purple-500/50"
                      : "bg-slate-800/50 border border-cyan-500/30"
                  } rounded-lg p-4`}
                >
                  {/* Message Header */}
                  <div className="flex items-center gap-2 mb-2">
                    {message.role === "user" ? (
                      <Badge variant="outline" className="text-xs">
                        You
                      </Badge>
                    ) : (
                      <div className="flex items-center gap-2">
                        <Badge
                          variant="outline"
                          className="text-xs bg-cyan-500/20 border-cyan-500/50"
                        >
                          <Brain className="w-3 h-3 mr-1" />
                          Agent
                        </Badge>
                        {message.reasoning && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-xs h-6 px-2"
                            onClick={() => {
                              setShowReasoning(!showReasoning);
                              setSelectedReasoningMessage(
                                selectedReasoningMessage === message.id ? null : message.id
                              );
                            }}
                          >
                            <Brain className="w-3 h-3 mr-1" />
                            Reasoning
                          </Button>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Message Content */}
                  <div className="text-sm text-white mb-3">
                    <Streamdown>{message.content}</Streamdown>
                  </div>

                  {/* Tool Calls Display */}
                  {message.toolCalls && message.toolCalls.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-purple-500/20">
                      <p className="text-xs font-semibold text-purple-300/60 mb-2">Tools Used:</p>
                      <div className="space-y-2">
                        {message.toolCalls.map((tool: any, i: number) => (
                          <div
                            key={i}
                            className="text-xs bg-slate-900/50 border border-purple-500/20 rounded p-2"
                          >
                            <p className="font-mono text-cyan-400">{tool.name}</p>
                            {tool.result && (
                              <p className="text-purple-300/60 mt-1 truncate">{tool.result}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Timestamp */}
                  <div className="text-xs text-purple-300/40 mt-2">
                    {message.createdAt.toLocaleTimeString()}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Reasoning Panel */}
          <AnimatePresence>
            {showReasoning &&
              selectedReasoningMessage &&
              messages.find((m) => m.id === selectedReasoningMessage)?.reasoning && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="col-span-full"
                >
                  <Card className="bg-gradient-to-r from-purple-900/30 to-cyan-900/30 border-purple-500/30 p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Brain className="w-4 h-4 text-cyan-400" />
                      <h3 className="text-sm font-semibold text-cyan-400">Agent Reasoning</h3>
                    </div>
                    <div className="text-sm text-purple-300/80 space-y-2">
                      <Streamdown>
                        {messages.find((m) => m.id === selectedReasoningMessage)?.reasoning ||
                          ""}
                      </Streamdown>
                    </div>

                    {/* Reasoning Steps */}
                    {messages.find((m) => m.id === selectedReasoningMessage)?.reasoningSteps &&
                      messages.find((m) => m.id === selectedReasoningMessage)!.reasoningSteps!
                        .length > 0 && (
                        <div className="mt-4 pt-4 border-t border-purple-500/20">
                          <p className="text-xs font-semibold text-purple-300/60 mb-3">
                            Reasoning Steps:
                          </p>
                          <div className="space-y-2">
                            {(messages
                              .find((m) => m.id === selectedReasoningMessage)
                              ?.reasoningSteps as any[])?.map((step: any, i: number) => (
                                <motion.div
                                  key={i}
                                  initial={{ opacity: 0, x: -10 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: i * 0.1 }}
                                  className="flex gap-3 text-xs"
                                >
                                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-cyan-500/20 border border-cyan-500/50 flex items-center justify-center">
                                    <span className="text-cyan-400 font-semibold">{i + 1}</span>
                                  </div>
                                  <div className="flex-1">
                                    <p className="font-semibold text-purple-300 capitalize">
                                      {step.type}
                                    </p>
                                    <p className="text-purple-300/60 mt-1">{step.content}</p>
                                  </div>
                                </motion.div>
                              ))}
                          </div>
                        </div>
                      )}
                  </Card>
                </motion.div>
              )}
          </AnimatePresence>

          {/* Loading State */}
          {sendMessageMutation.isPending && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-3 p-4 rounded-lg bg-slate-800/50 border border-cyan-500/30"
            >
              <Spinner className="w-5 h-5 text-cyan-400" />
              <div>
                <p className="text-sm font-medium text-cyan-400">Agent is thinking...</p>
                <p className="text-xs text-purple-300/60 mt-1">Analyzing your request</p>
              </div>
            </motion.div>
          )}

          <div ref={scrollRef} />
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="border-t border-purple-500/20 bg-slate-950/50 backdrop-blur-sm p-6">
        <div className="max-w-4xl mx-auto flex gap-3">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            placeholder="Ask me anything... (Shift+Enter for new line)"
            className="bg-slate-800/50 border-purple-500/30 text-white placeholder:text-purple-300/40 flex-1"
            disabled={sendMessageMutation.isPending}
            autoFocus
          />
          <Button
            onClick={handleSendMessage}
            disabled={sendMessageMutation.isPending || !input.trim()}
            className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 px-6"
          >
            {sendMessageMutation.isPending ? (
              <Spinner className="w-4 h-4" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
