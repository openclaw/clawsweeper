import { useState, useRef } from "react";
import { motion } from "framer-motion";
import { Mic, Square, Loader } from "lucide-react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";

interface VoiceInputProps {
  onTranscribed: (text: string) => void;
}

export default function VoiceInput({ onTranscribed }: VoiceInputProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const transcribeMutation = trpc.voiceTranscription.transcribe.useMutation({
    onSuccess: (result: any) => {
      setIsTranscribing(false);
      if (result.text) {
        onTranscribed(result.text);
      }
    },
    onError: () => {
      setIsTranscribing(false);
    },
  });

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);

      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" });

        // Upload audio and transcribe
        setIsTranscribing(true);

        // In a real implementation, upload to storage first
        // For now, we'll pass the blob directly
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64Audio = reader.result as string;
          // In production, upload to storage first and get URL
          // For now, we'll use a placeholder
          transcribeMutation.mutate({
            audioUrl: base64Audio,
            language: "en",
          });
        };
        reader.readAsDataURL(audioBlob);

        // Stop all tracks
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      mediaRecorderRef.current = mediaRecorder;
      setIsRecording(true);
    } catch (error) {
      console.error("Failed to start recording:", error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  return (
    <div className="flex items-center gap-2">
      {isRecording ? (
        <motion.div
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 1, repeat: Infinity }}
          className="flex items-center gap-2"
        >
          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
          <span className="text-xs text-red-400 font-medium">Recording...</span>
          <Button
            size="sm"
            variant="destructive"
            onClick={stopRecording}
            className="h-8 w-8 p-0"
          >
            <Square className="w-4 h-4" />
          </Button>
        </motion.div>
      ) : isTranscribing ? (
        <motion.div
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1, repeat: Infinity }}
          className="flex items-center gap-2"
        >
          <Loader className="w-4 h-4 text-cyan-400 animate-spin" />
          <span className="text-xs text-cyan-400 font-medium">Transcribing...</span>
        </motion.div>
      ) : (
        <Button
          size="sm"
          variant="outline"
          onClick={startRecording}
          className="h-8 w-8 p-0"
          title="Start voice input"
        >
          <Mic className="w-4 h-4" />
        </Button>
      )}
    </div>
  );
}
