import { useEffect, useState } from "react";
import { useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion } from "framer-motion";
import { ArrowLeft, Clock, CheckCircle, AlertCircle, Loader } from "lucide-react";
import { Streamdown } from "streamdown";

export default function TaskDetail() {
  const [, params] = useRoute("/tasks/:taskId");
  const taskId = params?.taskId ? parseInt(params.taskId) : null;

  const taskQuery = trpc.tasks.get.useQuery({ taskId: taskId! }, { enabled: !!taskId });
  const task = taskQuery.data;

  if (!taskId) return null;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case "failed":
        return <AlertCircle className="w-5 h-5 text-red-400" />;
      case "running":
        return <Loader className="w-5 h-5 text-cyan-400 animate-spin" />;
      default:
        return <Clock className="w-5 h-5 text-purple-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-500/20 border-green-500/50 text-green-300";
      case "failed":
        return "bg-red-500/20 border-red-500/50 text-red-300";
      case "running":
        return "bg-cyan-500/20 border-cyan-500/50 text-cyan-300";
      default:
        return "bg-purple-500/20 border-purple-500/50 text-purple-300";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 text-white">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20"
          animate={{ y: [0, 50, 0] }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div
          className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20"
          animate={{ y: [0, -50, 0] }}
          transition={{ duration: 10, repeat: Infinity }}
        />
      </div>

      <div className="relative z-10">
        {/* Header */}
        <div className="border-b border-purple-500/20 bg-slate-950/50 backdrop-blur-sm sticky top-0">
          <div className="max-w-6xl mx-auto px-6 py-4 flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => window.history.back()}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="text-2xl font-bold">Task Details</h1>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-6xl mx-auto px-6 py-8">
          {taskQuery.isLoading ? (
            <div className="flex items-center justify-center h-96">
              <Loader className="w-8 h-8 text-cyan-400 animate-spin" />
            </div>
          ) : !task ? (
            <Card className="bg-slate-800/50 border-red-500/30 p-6 text-center">
              <p className="text-red-300">Task not found</p>
            </Card>
          ) : (
            <div className="space-y-6">
              {/* Task Header Card */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-slate-800/50 border-purple-500/30 p-6">
                  <div className="flex items-start justify-between gap-4 mb-4">
                    <div className="flex-1">
                      <h2 className="text-3xl font-bold mb-2">{task.title}</h2>
                      <p className="text-purple-300/60">{task.description}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(task.status)}
                      <Badge className={`${getStatusColor(task.status)} border`}>
                        {task.status.charAt(0).toUpperCase() + task.status.slice(1)}
                      </Badge>
                    </div>
                  </div>

                  {/* Task Metadata */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-purple-500/20">
                    <div>
                      <p className="text-xs text-purple-300/60 mb-1">Priority</p>
                      <Badge variant="outline" className="text-xs capitalize">
                        {task.priority}
                      </Badge>
                    </div>
                    <div>
                      <p className="text-xs text-purple-300/60 mb-1">Created</p>
                      <p className="text-sm">
                        {new Date(task.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-purple-300/60 mb-1">Updated</p>
                      <p className="text-sm">
                        {new Date(task.updatedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-purple-300/60 mb-1">Task ID</p>
                      <p className="text-sm font-mono">{task.id}</p>
                    </div>
                  </div>
                </Card>
              </motion.div>

              {/* Execution Timeline */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <Card className="bg-slate-800/50 border-purple-500/30 p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-cyan-400" />
                    Execution Timeline
                  </h3>

                  <div className="space-y-4">
                    {/* Timeline Item - Created */}
                    <div className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="w-3 h-3 bg-cyan-400 rounded-full" />
                        <div className="w-0.5 h-12 bg-gradient-to-b from-cyan-400 to-purple-400" />
                      </div>
                      <div className="pb-4">
                        <p className="font-semibold text-cyan-400">Task Created</p>
                        <p className="text-sm text-purple-300/60">
                          {new Date(task.createdAt).toLocaleString()}
                        </p>
                      </div>
                    </div>

                    {/* Timeline Item - Status Change */}
                    {task.status !== "pending" && (
                      <div className="flex gap-4">
                        <div className="flex flex-col items-center">
                          <div className={`w-3 h-3 rounded-full ${
                            task.status === "completed" ? "bg-green-400" : "bg-red-400"
                          }`} />
                          <div className="w-0.5 h-12 bg-gradient-to-b from-purple-400 to-slate-600" />
                        </div>
                        <div className="pb-4">
                          <p className="font-semibold capitalize">
                            {task.status === "completed" ? (
                              <span className="text-green-400">Task Completed</span>
                            ) : (
                              <span className="text-red-400">Task Failed</span>
                            )}
                          </p>
                          <p className="text-sm text-purple-300/60">
                            {new Date(task.updatedAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Timeline Item - Current */}
                    {task.status === "running" && (
                      <div className="flex gap-4">
                        <div className="flex flex-col items-center">
                          <div className="w-3 h-3 bg-cyan-400 rounded-full animate-pulse" />
                        </div>
                        <div>
                          <p className="font-semibold text-cyan-400">Running</p>
                          <p className="text-sm text-purple-300/60">In progress...</p>
                        </div>
                      </div>
                    )}
                  </div>
                </Card>
              </motion.div>

              {/* Result / Error */}
              {(task.result || task.error) && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <Card className={`${
                    task.error
                      ? "bg-red-500/10 border-red-500/30"
                      : "bg-green-500/10 border-green-500/30"
                  } p-6`}>
                    <h3 className="text-lg font-semibold mb-4">
                      {task.error ? "Error Details" : "Result"}
                    </h3>
                    <ScrollArea className="h-64 rounded-lg bg-slate-900/50 p-4 border border-purple-500/20">
                      <Streamdown>
                        {task.error || task.result || "No output"}
                      </Streamdown>
                    </ScrollArea>
                  </Card>
                </motion.div>
              )}

              {/* Actions */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="flex gap-3"
              >
                <Button
                  variant="outline"
                  onClick={() => window.history.back()}
                >
                  Back to Tasks
                </Button>
              </motion.div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
