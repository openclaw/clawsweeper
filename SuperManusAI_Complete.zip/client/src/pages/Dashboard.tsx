import { useEffect, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import { MessageCircle, Zap, Brain, Clock, Settings, Plus } from "lucide-react";
import ChatInterface from "@/components/ChatInterface";

export default function Dashboard() {
  const { user } = useAuth();
  const [selectedConversation, setSelectedConversation] = useState<number | null>(null);
  const [selectedModel, setSelectedModel] = useState<"nemotron-4b" | "granite-4">("nemotron-4b");

  // Queries
  const conversationsQuery = trpc.conversations.list.useQuery();
  const tasksQuery = trpc.tasks.list.useQuery();
  const notificationsQuery = trpc.notifications.list.useQuery();

  // Mutations
  const createConversationMutation = trpc.conversations.create.useMutation({
    onSuccess: (data) => {
      setSelectedConversation(data.id);
      conversationsQuery.refetch();
    },
  });



  const handleCreateConversation = () => {
    createConversationMutation.mutate({
      title: `Conversation ${new Date().toLocaleTimeString()}`,
      model: selectedModel,
    });
  };



  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 text-white overflow-hidden">
      {/* Animated background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20"
          animate={{ y: [0, 50, 0] }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div
          className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20"
          animate={{ y: [0, -50, 0] }}
          transition={{ duration: 10, repeat: Infinity }}
        />
      </div>

      <div className="relative z-10 flex h-screen">
        {/* Sidebar */}
        <div className="w-64 border-r border-purple-500/20 bg-slate-950/50 backdrop-blur-sm flex flex-col">
          {/* Header */}
          <div className="p-6 border-b border-purple-500/20">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
              SuperManus AI
            </h1>
            <p className="text-xs text-purple-300/60 mt-2">Autonomous Agent Platform</p>
          </div>

          {/* New Conversation */}
          <div className="p-4">
            <Button
              onClick={handleCreateConversation}
              className="w-full bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white"
              disabled={createConversationMutation.isPending}
            >
              <Plus className="w-4 h-4 mr-2" />
              New Conversation
            </Button>
          </div>



          {/* Conversations List */}
          <div className="flex-1 overflow-y-auto px-4">
            <p className="text-xs font-semibold text-purple-300/60 mb-3">Recent Conversations</p>
            <div className="space-y-2">
              {conversationsQuery.data?.map((conv) => (
                <motion.button
                  key={conv.id}
                  onClick={() => setSelectedConversation(conv.id)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-all ${
                    selectedConversation === conv.id
                      ? "bg-purple-600/40 border border-purple-500/50"
                      : "hover:bg-purple-600/20 border border-transparent"
                  }`}
                  whileHover={{ x: 4 }}
                >
                  <div className="flex items-center gap-2">
                    <MessageCircle className="w-3 h-3 text-cyan-400" />
                    <span className="truncate">{conv.title}</span>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-purple-500/20 space-y-2">
            <Button variant="ghost" className="w-full text-sm justify-start text-purple-300/60 hover:text-purple-300">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          {selectedConversation ? (
            <>
              {/* Chat Interface */}
              <ChatInterface
                conversationId={selectedConversation}
                model={selectedModel}
                onModelChange={setSelectedModel}
              />
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <motion.div
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  className="w-16 h-16 mx-auto mb-6 rounded-full border-2 border-transparent border-t-cyan-400 border-r-purple-400"
                />
                <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent mb-2">
                  Welcome to SuperManus AI
                </h2>
                <p className="text-purple-300/60 mb-6">Start a new conversation to begin</p>
                <Button
                  onClick={handleCreateConversation}
                  className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700"
                  disabled={createConversationMutation.isPending}
                >
                  Create First Conversation
                </Button>
              </motion.div>
            </div>
          )}
        </div>

        {/* Right Sidebar - Tasks & Notifications */}
        <div className="w-80 border-l border-purple-500/20 bg-slate-950/50 backdrop-blur-sm flex flex-col">
          <Tabs defaultValue="tasks" className="flex-1 flex flex-col">
            <TabsList className="border-b border-purple-500/20 bg-transparent">
              <TabsTrigger value="tasks" className="text-xs">
                <Clock className="w-3 h-3 mr-1" />
                Tasks
              </TabsTrigger>
              <TabsTrigger value="notifications" className="text-xs">
                <Zap className="w-3 h-3 mr-1" />
                Notifications
              </TabsTrigger>
            </TabsList>

            <TabsContent value="tasks" className="flex-1 overflow-y-auto p-4 space-y-3">
              {tasksQuery.data?.slice(0, 5).map((task) => (
                <motion.div
                  key={task.id}
                  className="p-3 rounded-lg bg-slate-800/50 border border-purple-500/20"
                  whileHover={{ borderColor: "rgba(168, 85, 247, 0.5)" }}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <p className="text-sm font-medium text-white">{task.title}</p>
                      <p className="text-xs text-purple-300/60 mt-1">{task.description}</p>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {task.status}
                    </Badge>
                  </div>
                </motion.div>
              ))}
            </TabsContent>

            <TabsContent value="notifications" className="flex-1 overflow-y-auto p-4 space-y-3">
              {notificationsQuery.data?.slice(0, 5).map((notif) => (
                <motion.div
                  key={notif.id}
                  className="p-3 rounded-lg bg-slate-800/50 border border-purple-500/20"
                  whileHover={{ borderColor: "rgba(168, 85, 247, 0.5)" }}
                >
                  <p className="text-sm font-medium text-white">{notif.title}</p>
                  <p className="text-xs text-purple-300/60 mt-1">{notif.content}</p>
                </motion.div>
              ))}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
