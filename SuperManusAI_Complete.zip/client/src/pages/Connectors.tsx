import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Plus, Settings, Trash2, Github, Brain, Zap } from "lucide-react";

export default function Connectors() {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [formData, setFormData] = useState({
    connectorName: "",
    connectorType: "github",
    connectorUid: "",
  });

  const connectorsQuery = trpc.connectors.list.useQuery();
  const createMutation = trpc.connectors.create.useMutation({
    onSuccess: () => {
      setFormData({ connectorName: "", connectorType: "github", connectorUid: "" });
      setShowCreateDialog(false);
      connectorsQuery.refetch();
    },
  });

  const handleCreate = () => {
    if (!formData.connectorName || !formData.connectorUid) return;

    createMutation.mutate({
      connectorName: formData.connectorName,
      connectorType: formData.connectorType,
      connectorUid: formData.connectorUid,
    });
  };

  const getConnectorIcon = (type: string) => {
    switch (type) {
      case "github":
        return <Github className="w-5 h-5" />;
      case "huggingface":
        return <Brain className="w-5 h-5" />;
      case "custom":
        return <Zap className="w-5 h-5" />;
      default:
        return <Settings className="w-5 h-5" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 text-white">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20"
          animate={{ y: [0, 50, 0] }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div
          className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20"
          animate={{ y: [0, -50, 0] }}
          transition={{ duration: 10, repeat: Infinity }}
        />
      </div>

      <div className="relative z-10">
        {/* Header */}
        <div className="border-b border-purple-500/20 bg-slate-950/50 backdrop-blur-sm sticky top-0">
          <div className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-1">Connectors</h1>
              <p className="text-purple-300/60">Manage external integrations and APIs</p>
            </div>
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Connector
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-slate-900 border-purple-500/30">
                <DialogHeader>
                  <DialogTitle>Create New Connector</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-purple-300 mb-2 block">
                      Connector Name
                    </label>
                    <Input
                      value={formData.connectorName}
                      onChange={(e) =>
                        setFormData({ ...formData, connectorName: e.target.value })
                      }
                      placeholder="e.g., My GitHub Account"
                      className="bg-slate-800/50 border-purple-500/30"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-purple-300 mb-2 block">
                      Type
                    </label>
                    <select
                      value={formData.connectorType}
                      onChange={(e) =>
                        setFormData({ ...formData, connectorType: e.target.value })
                      }
                      className="w-full bg-slate-800/50 border border-purple-500/30 rounded-lg px-3 py-2 text-white"
                    >
                      <option value="github">GitHub</option>
                      <option value="huggingface">Hugging Face</option>
                      <option value="custom">Custom API</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-purple-300 mb-2 block">
                      Connector UID
                    </label>
                    <Input
                      value={formData.connectorUid}
                      onChange={(e) =>
                        setFormData({ ...formData, connectorUid: e.target.value })
                      }
                      placeholder="Unique identifier for this connector"
                      className="bg-slate-800/50 border-purple-500/30"
                    />
                  </div>

                  <Button
                    onClick={handleCreate}
                    disabled={createMutation.isPending}
                    className="w-full bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700"
                  >
                    Create Connector
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-6xl mx-auto px-6 py-8">
          {connectorsQuery.isLoading ? (
            <div className="text-center py-12">
              <p className="text-purple-300/60">Loading connectors...</p>
            </div>
          ) : !connectorsQuery.data || connectorsQuery.data.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-12"
            >
              <Settings className="w-12 h-12 mx-auto mb-4 text-purple-400/40" />
              <p className="text-purple-300/60 mb-4">No connectors configured yet</p>
              <Button
                onClick={() => setShowCreateDialog(true)}
                className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700"
              >
                Create Your First Connector
              </Button>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {connectorsQuery.data.map((connector: any, idx: number) => (
                <motion.div
                  key={connector.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                >
                  <Card className="bg-slate-800/50 border-purple-500/30 p-6 hover:border-purple-500/50 transition-all">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-cyan-500/20 border border-cyan-500/50 rounded-lg text-cyan-400">
                          {getConnectorIcon(connector.connectorType)}
                        </div>
                        <div>
                          <h3 className="font-semibold text-white">{connector.connectorName}</h3>
                          <p className="text-xs text-purple-300/60 mt-1">
                            {connector.connectorUid}
                          </p>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-xs capitalize">
                        {connector.connectorType}
                      </Badge>
                    </div>

                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        <Settings className="w-3 h-3 mr-1" />
                        Configure
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-red-400 hover:text-red-300"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
