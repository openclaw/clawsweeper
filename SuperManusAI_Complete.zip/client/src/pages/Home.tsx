import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { motion } from "framer-motion";
import { ArrowRight, Zap, Brain, Sparkles } from "lucide-react";

export default function Home() {
  const { isAuthenticated } = useAuth();

  if (isAuthenticated) {
    return null; // Will redirect to Dashboard via App.tsx
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-900 to-slate-900 text-white overflow-hidden">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20"
          animate={{ y: [0, 50, 0] }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div
          className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20"
          animate={{ y: [0, -50, 0] }}
          transition={{ duration: 10, repeat: Infinity }}
        />
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4">
        {/* Main Content */}
        <motion.div
          className="text-center max-w-4xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Logo/Title */}
          <motion.div
            className="mb-8"
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            <div className="w-20 h-20 mx-auto rounded-full border-2 border-transparent border-t-cyan-400 border-r-purple-400 flex items-center justify-center">
              <Brain className="w-10 h-10 text-purple-400" />
            </div>
          </motion.div>

          <h1 className="text-6xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="bg-gradient-to-r from-purple-400 via-cyan-400 to-purple-400 bg-clip-text text-transparent">
              SuperManus AI
            </span>
          </h1>

          <p className="text-xl md:text-2xl text-purple-300/80 mb-8 leading-relaxed">
            The next-generation autonomous agent platform. Powered by Granite 4 and Nemotron 4B for ultra-powerful reasoning and lightning-fast responses.
          </p>

          {/* Features Grid */}
          <div className="grid md:grid-cols-3 gap-6 mb-12 py-8">
            <motion.div
              className="p-6 rounded-lg bg-purple-600/10 border border-purple-500/30 backdrop-blur-sm"
              whileHover={{ borderColor: "rgba(168, 85, 247, 0.8)" }}
            >
              <Brain className="w-8 h-8 text-cyan-400 mx-auto mb-3" />
              <h3 className="font-semibold mb-2">Ultra-Powerful Reasoning</h3>
              <p className="text-sm text-purple-300/60">Multi-path exploration and chain-of-thought decomposition</p>
            </motion.div>

            <motion.div
              className="p-6 rounded-lg bg-purple-600/10 border border-purple-500/30 backdrop-blur-sm"
              whileHover={{ borderColor: "rgba(168, 85, 247, 0.8)" }}
            >
              <Zap className="w-8 h-8 text-cyan-400 mx-auto mb-3" />
              <h3 className="font-semibold mb-2">Lightning Fast</h3>
              <p className="text-sm text-purple-300/60">Nemotron 4B for rapid, efficient responses</p>
            </motion.div>

            <motion.div
              className="p-6 rounded-lg bg-purple-600/10 border border-purple-500/30 backdrop-blur-sm"
              whileHover={{ borderColor: "rgba(168, 85, 247, 0.8)" }}
            >
              <Sparkles className="w-8 h-8 text-cyan-400 mx-auto mb-3" />
              <h3 className="font-semibold mb-2">Autonomous Execution</h3>
              <p className="text-sm text-purple-300/60">Real-time task planning and execution</p>
            </motion.div>
          </div>

          {/* CTA Button */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <a href={getLoginUrl()}>
              <Button className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 text-white px-8 py-6 text-lg font-semibold rounded-lg">
                Get Started
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </a>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
